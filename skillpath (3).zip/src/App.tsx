import React from 'react';
import { RouterProvider, useRouter } from './router';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { IntroLayer } from './components/IntroLayer';
import { Home } from './pages/Home';
import { FindGap } from './pages/FindGap';
import { HowItWorks } from './pages/HowItWorks';
import { About } from './pages/About';
import { Login } from './pages/Login';
import { SignUp } from './pages/SignUp';
import { Contact } from './pages/Contact';
import { NotFound } from './pages/NotFound';

const AppContent: React.FC = () => {
  const { path, hasSeenIntro, setHasSeenIntro } = useRouter();

  // Route switcher
  const renderRoute = () => {
    switch (path) {
      case '/':
        return <Home />;
      case '/find-gap':
        return <FindGap />;
      case '/how-it-works':
        return <HowItWorks />;
      case '/about':
        return <About />;
      case '/login':
        return <Login />;
      case '/signup':
        return <SignUp />;
      case '/contact':
        return <Contact />;
      default:
        return <NotFound />;
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#060815] text-[#f5f6fa] relative selection:bg-[#f72585] selection:text-white">
      {/* LAYER 1: Fullscreen Intro Animation if not yet dismissed */}
      {!hasSeenIntro && (
        <IntroLayer onComplete={() => setHasSeenIntro(true)} />
      )}

      {/* LAYER 2: Main Website */}
      <div
        id="skillpath-main-layer"
        className={`flex-1 flex flex-col transition-opacity duration-700 ${
          hasSeenIntro ? 'opacity-100' : 'opacity-0 pointer-events-none'
        }`}
      >
        <Navbar />
        <main className="flex-1 flex flex-col">{renderRoute()}</main>
        <Footer />
      </div>
    </div>
  );
};

export default function App() {
  return (
    <RouterProvider>
      <AppContent />
    </RouterProvider>
  );
}
