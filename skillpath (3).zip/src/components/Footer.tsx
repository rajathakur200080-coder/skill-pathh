import React from 'react';
import { useRouter, Link } from '../router';
import { Sparkles, ArrowUpRight, Play, Heart } from 'lucide-react';

export const Footer: React.FC = () => {
  const { replayIntro } = useRouter();

  return (
    <footer id="main-footer" className="w-full bg-[#04060f] border-t border-white/[0.08] pt-16 pb-12 mt-auto">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-10 pb-12 border-b border-white/[0.06]">
          {/* Col 1: Brand & Mission */}
          <div className="md:col-span-2 space-y-4">
            <Link to="/" className="inline-flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#4361ee] to-[#f72585] flex items-center justify-center shadow-md shadow-[#4361ee]/20">
                <span className="text-white font-extrabold text-base">S</span>
              </div>
              <span className="text-xl font-bold tracking-tight text-white">
                Skill<span className="bg-gradient-to-r from-[#4361ee] to-[#f72585] bg-clip-text text-transparent">Path</span>
              </span>
            </Link>

            <p className="text-sm text-[#a0a4c1] max-w-md leading-relaxed">
              SkillPath bridges the gap between university syllabi and real industry requirements. We analyze degree programs to map exact skill deficiencies and connect students directly to verified, 100% free learning resources.
            </p>

            <div className="pt-2 flex flex-wrap gap-2">
              <span className="text-[11px] px-2.5 py-1 rounded-full bg-white/5 border border-white/10 text-[#a0a4c1]">
                300+ Students Guided
              </span>
              <span className="text-[11px] px-2.5 py-1 rounded-full bg-white/5 border border-white/10 text-[#a0a4c1]">
                5+ Degree Paths
              </span>
              <span className="text-[11px] px-2.5 py-1 rounded-full bg-white/5 border border-white/10 text-emerald-400">
                100% Free Resources
              </span>
            </div>
          </div>

          {/* Col 2: Navigation Links */}
          <div className="space-y-3">
            <div className="text-xs font-semibold uppercase tracking-wider text-white">
              Platform
            </div>
            <ul className="space-y-2 text-sm text-[#a0a4c1]">
              <li>
                <Link to="/" className="hover:text-white transition-colors">
                  Home
                </Link>
              </li>
              <li>
                <Link to="/find-gap" className="hover:text-white transition-colors flex items-center gap-1">
                  Find My Gap
                  <span className="text-[10px] text-pink-400 font-mono">Popular</span>
                </Link>
              </li>
              <li>
                <Link to="/how-it-works" className="hover:text-white transition-colors">
                  How It Works
                </Link>
              </li>
              <li>
                <Link to="/about" className="hover:text-white transition-colors">
                  About Us
                </Link>
              </li>
              <li>
                <Link to="/contact" className="hover:text-white transition-colors">
                  Contact
                </Link>
              </li>
            </ul>
          </div>

          {/* Col 3: Degree Pathways & Extras */}
          <div className="space-y-3">
            <div className="text-xs font-semibold uppercase tracking-wider text-white">
              Degree Pathways
            </div>
            <ul className="space-y-2 text-sm text-[#a0a4c1]">
              <li>
                <Link to="/find-gap" className="hover:text-white transition-colors">
                  BCA — Software & DevOps
                </Link>
              </li>
              <li>
                <Link to="/find-gap" className="hover:text-white transition-colors">
                  BCom — Financial Modeling & BI
                </Link>
              </li>
              <li>
                <Link to="/find-gap" className="hover:text-white transition-colors">
                  BBA — Performance Growth & PM
                </Link>
              </li>
              <li>
                <Link to="/find-gap" className="hover:text-white transition-colors">
                  BA — UX Writing & Product Design
                </Link>
              </li>
              <li>
                <Link to="/find-gap" className="hover:text-white transition-colors">
                  MBA — Product Analytics & AI Strategy
                </Link>
              </li>
            </ul>

            <div className="pt-2">
              <button
                onClick={replayIntro}
                className="inline-flex items-center gap-1.5 text-xs text-[#a0a4c1] hover:text-[#f72585] transition-colors py-1 cursor-pointer"
                title="Watch intro animation again"
              >
                <Play className="w-3 h-3 fill-current" />
                <span>Replay Intro Animation</span>
              </button>
            </div>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-[#a0a4c1]">
          <p>&copy; {new Date().getFullYear()} SkillPath. Built for ambitious students worldwide.</p>
          <div className="flex items-center gap-6">
            <Link to="/about" className="hover:text-white transition-colors">
              Privacy Policy
            </Link>
            <Link to="/about" className="hover:text-white transition-colors">
              Terms of Service
            </Link>
            <Link to="/contact" className="hover:text-white transition-colors">
              Help Center
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
};
