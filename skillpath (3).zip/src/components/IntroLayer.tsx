import React, { useState, useEffect } from 'react';
import { Sparkles, ArrowRight, Code2, Database, TrendingUp, Layers, Terminal } from 'lucide-react';

interface IntroLayerProps {
  onComplete: () => void;
}

export const IntroLayer: React.FC<IntroLayerProps> = ({ onComplete }) => {
  const [isFadingOut, setIsFadingOut] = useState(false);
  const [showTitle, setShowTitle] = useState(false);
  const [showButton, setShowButton] = useState(false);
  const [prefersReducedMotion, setPrefersReducedMotion] = useState(false);

  useEffect(() => {
    // Check prefers-reduced-motion
    if (typeof window !== 'undefined') {
      const mediaQuery = window.matchMedia('(prefers-reduced-motion: reduce)');
      setPrefersReducedMotion(mediaQuery.matches);
      const listener = (e: MediaQueryListEvent) => setPrefersReducedMotion(e.matches);
      mediaQuery.addEventListener('change', listener);
      return () => mediaQuery.removeEventListener('change', listener);
    }
  }, []);

  useEffect(() => {
    // Staggered reveal
    const titleTimer = setTimeout(() => {
      setShowTitle(true);
    }, 600);

    const buttonTimer = setTimeout(() => {
      setShowButton(true);
    }, 1500);

    return () => {
      clearTimeout(titleTimer);
      clearTimeout(buttonTimer);
    };
  }, []);

  const handleStart = () => {
    setIsFadingOut(true);
    setTimeout(() => {
      onComplete();
    }, 600);
  };

  return (
    <div
      id="skillpath-intro-layer"
      className={`fixed inset-0 z-50 flex flex-col items-center justify-center overflow-hidden bg-gradient-to-b from-[#0a0e27] via-[#080c22] to-[#060815] transition-all duration-700 ease-out ${
        isFadingOut ? 'opacity-0 scale-105 pointer-events-none' : 'opacity-100 scale-100'
      }`}
      style={{ minHeight: '100vh', width: '100vw' }}
    >
      {/* Subtle radial lighting */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-[#4361ee]/15 rounded-full blur-3xl pointer-events-none animate-pulse-glow" />
      <div className="absolute top-1/3 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[400px] h-[300px] bg-[#f72585]/10 rounded-full blur-3xl pointer-events-none" />

      {/* Top right Skip button */}
      <div className="absolute top-6 right-6 z-20">
        <button
          id="intro-skip-button"
          onClick={handleStart}
          className="text-xs uppercase tracking-wider text-[#a0a4c1] hover:text-white transition-colors duration-200 px-3 py-1.5 rounded-full border border-white/10 hover:border-white/20 bg-white/5 backdrop-blur-sm cursor-pointer"
          aria-label="Skip animated intro"
        >
          Skip Intro &rarr;
        </button>
      </div>

      {/* Main Center Area: Stylized Laptop + Orbiting Elements */}
      <div className="relative flex flex-col items-center justify-center max-w-4xl w-full px-4">
        
        {/* Floating cards around laptop */}
        <div className="relative w-full max-w-[540px] h-[320px] sm:h-[360px] flex items-center justify-center">

          {/* Floating Element 1: React / Frontend Card (Top Left) */}
          <div
            className={`absolute -top-4 sm:-top-6 left-2 sm:left-4 z-10 hidden xs:flex items-center gap-2.5 px-3.5 py-2 rounded-xl bg-[#0a0e27]/90 border border-[#4361ee]/30 shadow-lg shadow-[#4361ee]/10 backdrop-blur-md ${
              prefersReducedMotion ? '' : 'animate-float-1'
            }`}
          >
            <div className="w-6 h-6 rounded-lg bg-[#4361ee]/20 flex items-center justify-center text-[#4361ee]">
              <Code2 className="w-3.5 h-3.5" />
            </div>
            <div className="text-left">
              <div className="text-[11px] font-medium text-white">React 19 & APIs</div>
              <div className="text-[9px] text-[#a0a4c1]">Industry In-Demand</div>
            </div>
          </div>

          {/* Floating Element 2: SQL / Database Card (Top Right) */}
          <div
            className={`absolute top-2 sm:top-4 -right-2 sm:right-2 z-10 hidden xs:flex items-center gap-2.5 px-3.5 py-2 rounded-xl bg-[#0a0e27]/90 border border-[#f72585]/30 shadow-lg shadow-[#f72585]/10 backdrop-blur-md ${
              prefersReducedMotion ? '' : 'animate-float-2'
            }`}
          >
            <div className="w-6 h-6 rounded-lg bg-[#f72585]/20 flex items-center justify-center text-[#f72585]">
              <Database className="w-3.5 h-3.5" />
            </div>
            <div className="text-left">
              <div className="text-[11px] font-medium text-white">PostgreSQL Indexing</div>
              <div className="text-[9px] text-emerald-400">100% Free Resource</div>
            </div>
          </div>

          {/* Floating Element 3: Finance Analytics Card (Bottom Left) */}
          <div
            className={`absolute -bottom-2 sm:bottom-0 left-0 sm:left-2 z-10 hidden sm:flex items-center gap-2.5 px-3.5 py-2 rounded-xl bg-[#0a0e27]/90 border border-emerald-500/30 shadow-lg backdrop-blur-md ${
              prefersReducedMotion ? '' : 'animate-float-3'
            }`}
          >
            <div className="w-6 h-6 rounded-lg bg-emerald-500/20 flex items-center justify-center text-emerald-400">
              <TrendingUp className="w-3.5 h-3.5" />
            </div>
            <div className="text-left">
              <div className="text-[11px] font-medium text-white">Financial Modeling</div>
              <div className="text-[9px] text-[#a0a4c1]">BCom Gap Solved</div>
            </div>
          </div>

          {/* Floating Element 4: Design Systems (Bottom Right) */}
          <div
            className={`absolute bottom-6 -right-4 sm:right-0 z-10 hidden sm:flex items-center gap-2.5 px-3 py-1.5 rounded-xl bg-[#0a0e27]/90 border border-amber-500/30 shadow-lg backdrop-blur-md ${
              prefersReducedMotion ? '' : 'animate-float-1'
            }`}
          >
            <div className="w-5 h-5 rounded-lg bg-amber-500/20 flex items-center justify-center text-amber-400">
              <Layers className="w-3 h-3" />
            </div>
            <div className="text-[10px] font-medium text-white">Figma Design Systems</div>
          </div>

          {/* Stylized Laptop Illustration */}
          <div className="relative w-[340px] sm:w-[440px] aspect-[16/10] bg-[#121634] rounded-t-2xl p-2.5 sm:p-3 border border-white/10 shadow-2xl shadow-black/80 flex flex-col">
            
            {/* Screen Bezel and Camera */}
            <div className="w-full flex items-center justify-center pb-1.5">
              <div className="w-1.5 h-1.5 rounded-full bg-white/30" />
            </div>

            {/* Laptop Display (Screen Surface) */}
            <div className="relative flex-1 bg-[#070a1a] rounded-lg border border-white/5 overflow-hidden flex flex-col p-3 select-none">
              
              {/* Display Header */}
              <div className="flex items-center justify-between pb-2 border-b border-white/5">
                <div className="flex items-center gap-1.5">
                  <div className="w-2.5 h-2.5 rounded-full bg-rose-500/70" />
                  <div className="w-2.5 h-2.5 rounded-full bg-amber-500/70" />
                  <div className="w-2.5 h-2.5 rounded-full bg-emerald-500/70" />
                </div>
                <div className="text-[10px] text-[#a0a4c1] font-mono flex items-center gap-1">
                  <Terminal className="w-3 h-3 text-[#4361ee]" /> skillpath-mapper.ts
                </div>
                <div className="text-[9px] text-[#4361ee] font-medium bg-[#4361ee]/10 px-1.5 py-0.5 rounded">
                  Live Match
                </div>
              </div>

              {/* Display Content: Simulated Skill Graph & Interactive Nodes */}
              <div className="relative flex-1 pt-2 grid grid-cols-3 gap-2">
                {/* Degree target node */}
                <div className="col-span-1 bg-[#0a0e27] rounded border border-[#4361ee]/40 p-2 flex flex-col justify-between">
                  <div>
                    <div className="text-[8px] text-[#a0a4c1] uppercase">Degree</div>
                    <div className="text-[11px] font-semibold text-white">BCA / BCom</div>
                  </div>
                  <div className="w-full bg-white/5 h-1.5 rounded-full overflow-hidden">
                    <div className="bg-gradient-to-r from-[#4361ee] to-[#f72585] h-full w-[85%]" />
                  </div>
                </div>

                {/* Gap detection graph node */}
                <div className="col-span-2 bg-[#0a0e27] rounded border border-white/5 p-2 flex flex-col justify-between">
                  <div className="flex justify-between items-center">
                    <span className="text-[9px] text-white font-medium">Industry Skill Gaps</span>
                    <span className="text-[8px] text-emerald-400 font-mono">+4 Gaps Mapped</span>
                  </div>
                  <div className="space-y-1 mt-1">
                    <div className="flex items-center justify-between text-[8px] text-[#a0a4c1]">
                      <span>React & Node</span>
                      <span className="text-[#f72585]">94% Match</span>
                    </div>
                    <div className="flex items-center justify-between text-[8px] text-[#a0a4c1]">
                      <span>Git Workflow</span>
                      <span className="text-[#4361ee]">88% Match</span>
                    </div>
                  </div>
                </div>

                {/* Bottom live code row */}
                <div className="col-span-3 bg-[#050713] rounded p-2 border border-white/5 font-mono text-[9px] text-[#a0a4c1] flex items-center justify-between">
                  <div className="flex items-center gap-1.5">
                    <span className="text-pink-400">const</span>
                    <span className="text-blue-300">future</span>
                    <span>=</span>
                    <span className="text-emerald-300">learnFree</span>();
                  </div>
                  <div className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                </div>
              </div>

              {/* Animated Looping Cursor inside screen */}
              {!prefersReducedMotion && (
                <div
                  className="absolute pointer-events-none z-30 animate-cursor-loop text-white drop-shadow-[0_2px_8px_rgba(247,37,133,0.6)]"
                  style={{ top: 0, left: 0 }}
                >
                  <svg
                    width="18"
                    height="18"
                    viewBox="0 0 24 24"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M3 3L10.07 19.97L12.58 12.58L19.97 10.07L3 3Z"
                      fill="#f72585"
                      stroke="#ffffff"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                  </svg>
                </div>
              )}
            </div>

            {/* Laptop Base / Keyboard Hinge */}
            <div className="w-full flex justify-center mt-1">
              <div className="w-16 h-1 bg-white/20 rounded-full" />
            </div>
          </div>

          {/* Laptop Bottom Lip / Trackpad Deck */}
          <div className="absolute -bottom-2.5 sm:-bottom-3.5 w-[370px] sm:w-[480px] h-3 sm:h-4 bg-[#1b2046] rounded-b-xl border-t border-white/20 shadow-xl flex justify-center items-center">
            <div className="w-16 sm:w-20 h-1 bg-[#0a0e27] rounded-sm" />
          </div>
        </div>

        {/* Brand Name "SkillPath" and Subheadline with Entrance Animation */}
        <div
          className={`mt-10 sm:mt-12 text-center transition-all duration-700 transform ${
            showTitle ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
          }`}
        >
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/5 border border-white/10 text-xs text-[#a0a4c1] mb-3">
            <Sparkles className="w-3.5 h-3.5 text-[#f72585]" />
            <span>Bridge College Theory & Industry Reality</span>
          </div>

          <h1 className="text-4xl sm:text-5xl font-extrabold tracking-tight text-white mb-2">
            Skill<span className="bg-gradient-to-r from-[#4361ee] to-[#f72585] bg-clip-text text-transparent">Path</span>
          </h1>
          <p className="text-sm sm:text-base text-[#a0a4c1] max-w-md mx-auto">
            Discover the exact skills your industry demands and where to master them for 100% free.
          </p>
        </div>

        {/* "Get Started" Single Button Fading in after ~1.5s */}
        <div
          className={`mt-6 transition-all duration-700 transform ${
            showButton ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
          }`}
        >
          <button
            id="intro-get-started-button"
            onClick={handleStart}
            className="group relative inline-flex items-center gap-2.5 px-8 py-3.5 rounded-full font-semibold text-white bg-gradient-to-r from-[#4361ee] to-[#f72585] hover:opacity-95 shadow-lg shadow-[#4361ee]/25 hover:shadow-[#f72585]/30 hover:scale-[1.03] active:scale-[0.98] transition-all duration-200 cursor-pointer focus:outline-none focus:ring-2 focus:ring-[#f72585] focus:ring-offset-2 focus:ring-offset-[#060815]"
          >
            <span>Get Started</span>
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform duration-200" />
          </button>
        </div>

      </div>
    </div>
  );
};
