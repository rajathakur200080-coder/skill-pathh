import React, { useState, useEffect } from 'react';
import { useRouter, Link } from '../router';
import { Menu, X, Sparkles, LogOut, User, Compass } from 'lucide-react';

export const Navbar: React.FC = () => {
  const { path, user, logout } = useRouter();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Close mobile menu when route changes
  useEffect(() => {
    setIsMobileMenuOpen(false);
  }, [path]);

  const navLinks = [
    { name: 'Home', href: '/' },
    { name: 'Find My Gap', href: '/find-gap' },
    { name: 'How It Works', href: '/how-it-works' },
    { name: 'About Us', href: '/about' },
    { name: 'Contact', href: '/contact' },
  ];

  return (
    <header
      id="main-navbar"
      className={`sticky top-0 z-40 w-full transition-all duration-300 ${
        scrolled
          ? 'bg-[#060815]/90 backdrop-blur-md border-b border-white/[0.08] shadow-lg shadow-black/40'
          : 'bg-transparent border-b border-transparent'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
        {/* Left: Logo */}
        <Link
          to="/"
          id="navbar-logo"
          className="flex items-center gap-3 group focus:outline-none focus:ring-2 focus:ring-[#4361ee] rounded-lg p-1"
        >
          {/* Small gradient square mark */}
          <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-[#4361ee] to-[#f72585] flex items-center justify-center shadow-md shadow-[#4361ee]/30 group-hover:scale-105 transition-transform duration-200">
            <span className="text-white font-extrabold text-lg tracking-tight">S</span>
          </div>
          <div className="flex flex-col">
            <span className="text-xl font-bold tracking-tight text-[#f5f6fa]">
              Skill<span className="bg-gradient-to-r from-[#4361ee] to-[#f72585] bg-clip-text text-transparent">Path</span>
            </span>
          </div>
        </Link>

        {/* Center: Nav links (visible >= 900px / min-w-[900px]) */}
        <nav className="hidden min-[900px]:flex items-center gap-1.5 lg:gap-2">
          {navLinks.map((link) => {
            const isActive = path === link.href;
            return (
              <Link
                key={link.name}
                to={link.href}
                id={`nav-link-${link.name.toLowerCase().replace(/\s+/g, '-')}`}
                className={`relative px-3.5 py-2 rounded-lg text-sm font-medium transition-all duration-200 ${
                  isActive
                    ? 'text-white bg-white/[0.08]'
                    : 'text-[#a0a4c1] hover:text-white hover:bg-white/[0.04]'
                }`}
              >
                {link.name}
                {isActive && (
                  <span className="absolute bottom-0 left-3.5 right-3.5 h-[2px] bg-gradient-to-r from-[#4361ee] to-[#f72585] rounded-full" />
                )}
              </Link>
            );
          })}
        </nav>

        {/* Right: Auth Buttons (visible >= 900px) and Mobile controls */}
        <div className="flex items-center gap-3">
          {user.isLoggedIn ? (
            <div className="hidden min-[900px]:flex items-center gap-3">
              <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/5 border border-white/10 text-xs text-[#f5f6fa]">
                <div className="w-5 h-5 rounded-full bg-gradient-to-br from-[#4361ee] to-[#f72585] flex items-center justify-center text-[10px] font-bold">
                  {user.name?.charAt(0) || 'U'}
                </div>
                <span>{user.name}</span>
              </div>
              <button
                id="nav-logout-btn"
                onClick={logout}
                className="p-2 text-[#a0a4c1] hover:text-white hover:bg-white/5 rounded-lg transition-colors duration-200"
                title="Logout"
                aria-label="Logout from account"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          ) : (
            <div className="flex items-center gap-3">
              {/* Outlined Login button (hidden below 900px per spec) */}
              <Link
                to="/login"
                id="nav-login-btn"
                className="hidden min-[900px]:inline-flex items-center justify-center px-4 py-2 rounded-lg text-sm font-medium text-[#f5f6fa] border border-white/20 hover:border-white/40 hover:bg-white/5 transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-[#4361ee]"
              >
                Login
              </Link>

              {/* Gradient filled Sign Up button (always visible) */}
              <Link
                to="/signup"
                id="nav-signup-btn"
                className="inline-flex items-center justify-center px-4 py-2 rounded-lg text-sm font-medium text-white bg-gradient-to-r from-[#4361ee] to-[#f72585] hover:opacity-95 shadow-md shadow-[#4361ee]/20 hover:scale-[1.02] active:scale-[0.98] transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-[#f72585]"
              >
                Sign Up
              </Link>
            </div>
          )}

          {/* Mobile hamburger button (< 900px) */}
          <button
            id="mobile-menu-toggle"
            type="button"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="min-[900px]:hidden p-2 rounded-lg text-[#a0a4c1] hover:text-white hover:bg-white/10 focus:outline-none focus:ring-2 focus:ring-[#4361ee] transition-colors"
            aria-label={isMobileMenuOpen ? 'Close navigation menu' : 'Open navigation menu'}
            aria-expanded={isMobileMenuOpen}
          >
            {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile slide-in / full-width navigation drawer */}
      {isMobileMenuOpen && (
        <div
          id="mobile-drawer"
          className="min-[900px]:hidden fixed inset-x-0 top-20 bottom-0 bg-[#060815]/95 backdrop-blur-xl border-t border-white/10 z-50 flex flex-col p-6 animate-in fade-in slide-in-from-top-4 duration-200 overflow-y-auto"
        >
          <div className="flex flex-col space-y-2">
            {navLinks.map((link) => {
              const isActive = path === link.href;
              return (
                <Link
                  key={link.name}
                  to={link.href}
                  id={`mobile-nav-${link.name.toLowerCase().replace(/\s+/g, '-')}`}
                  className={`flex items-center justify-between px-4 py-3.5 rounded-xl text-base font-medium transition-colors ${
                    isActive
                      ? 'bg-gradient-to-r from-[#4361ee]/20 to-[#f72585]/20 text-white border border-[#4361ee]/30'
                      : 'text-[#a0a4c1] hover:text-white hover:bg-white/5'
                  }`}
                >
                  <span>{link.name}</span>
                  {isActive && <span className="w-2 h-2 rounded-full bg-[#f72585]" />}
                </Link>
              );
            })}
          </div>

          <div className="mt-8 pt-6 border-t border-white/10 flex flex-col gap-3">
            {user.isLoggedIn ? (
              <div className="flex flex-col gap-3">
                <div className="flex items-center gap-3 p-3 rounded-xl bg-white/5 border border-white/10">
                  <div className="w-9 h-9 rounded-full bg-gradient-to-br from-[#4361ee] to-[#f72585] flex items-center justify-center font-bold text-white">
                    {user.name?.charAt(0) || 'U'}
                  </div>
                  <div>
                    <div className="text-sm font-medium text-white">{user.name}</div>
                    <div className="text-xs text-[#a0a4c1]">{user.email}</div>
                  </div>
                </div>
                <button
                  onClick={logout}
                  className="flex items-center justify-center gap-2 py-3 rounded-xl border border-red-500/30 text-red-400 hover:bg-red-500/10 font-medium text-sm transition-colors"
                >
                  <LogOut className="w-4 h-4" />
                  Logout
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-2 gap-3">
                <Link
                  to="/login"
                  id="mobile-menu-login-btn"
                  className="w-full py-3 rounded-xl text-center text-sm font-medium text-white border border-white/20 hover:bg-white/5 transition-colors"
                >
                  Login
                </Link>
                <Link
                  to="/signup"
                  id="mobile-menu-signup-btn"
                  className="w-full py-3 rounded-xl text-center text-sm font-medium text-white bg-gradient-to-r from-[#4361ee] to-[#f72585] shadow-md shadow-[#4361ee]/20"
                >
                  Sign Up
                </Link>
              </div>
            )}

            <div className="mt-4 p-4 rounded-xl bg-[#0a0e27] border border-white/5 text-center">
              <p className="text-xs text-[#a0a4c1]">
                Empowering college students across BCA, BCom, BBA, BA & MBA to achieve industry readiness.
              </p>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};
