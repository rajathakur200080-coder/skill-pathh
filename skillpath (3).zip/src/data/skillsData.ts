import { DegreeData } from '../types';

export const DEGREES_DATA: DegreeData[] = [
  {
    id: 'bca',
    code: 'BCA',
    title: 'Bachelor of Computer Applications',
    summary: 'Bridging the chasm between legacy college syllabi and fast-paced tech startups.',
    industryReality: 'University exams prioritize theoretical C and syntax memorization; hiring managers hire for production Git workflows, reactive UI engineering, and API pipelines.',
    iconName: 'Code2',
    skills: [
      {
        id: 'bca-1',
        name: 'Full-Stack Web Engineering (React & Node.js)',
        category: 'Development',
        whyItMatters: '90% of tech job openings for junior developers require practical knowledge of reactive component state and REST/GraphQL APIs over static HTML pages.',
        syllabusGap: 'Most universities teach 2000s-era static web design or legacy Java applets without modern component-driven architectures.',
        estimatedHours: '60 hrs',
        freeResourceTitle: 'Full Stack Open & The Odin Project',
        freeResourceProvider: 'University of Helsinki & Open Source Community',
        freeResourceUrl: 'https://fullstackopen.com/en/',
        badge: 'Top Market Demand'
      },
      {
        id: 'bca-2',
        name: 'Git, GitHub & Production Collaboration',
        category: 'DevOps & Tooling',
        whyItMatters: 'No software is built in isolation; branches, PR reviews, and merge conflicts are daily expectations from day one on the job.',
        syllabusGap: 'Treated as an afterthought or completely omitted in college computer lab exams.',
        estimatedHours: '15 hrs',
        freeResourceTitle: 'Learn Git Branching & GitHub Skills',
        freeResourceProvider: 'Interactive Visual Sandbox',
        freeResourceUrl: 'https://learngitbranching.js.org/',
        badge: 'Workplace Essential'
      },
      {
        id: 'bca-3',
        name: 'Practical Data Structures & LeetCode Patterns',
        category: 'Algorithms',
        whyItMatters: 'Technical interview rounds at modern tech companies exclusively test algorithmic problem solving, time complexities, and pattern recognition.',
        syllabusGap: 'Academic exams emphasize memorizing handwritten code on paper rather than solving edge cases in live runtimes.',
        estimatedHours: '45 hrs',
        freeResourceTitle: 'CS50x: Introduction to Computer Science',
        freeResourceProvider: 'Harvard University',
        freeResourceUrl: 'https://cs50.harvard.edu/x/',
        badge: 'Interview Critical'
      },
      {
        id: 'bca-4',
        name: 'Modern SQL & PostgreSQL Query Optimization',
        category: 'Databases',
        whyItMatters: 'Real-world data isn’t tiny 4-row tables; engineers must know indexing, execution plans, joins, and transactions at scale.',
        syllabusGap: 'Curricula dwell extensively on relational calculus and textbook normalization without live database indexing.',
        estimatedHours: '25 hrs',
        freeResourceTitle: 'SQLBolt & PostgreSQL Interactive Mastery',
        freeResourceProvider: 'Interactive Labs',
        freeResourceUrl: 'https://sqlbolt.com/',
        badge: 'High Salary Impact'
      },
      {
        id: 'bca-5',
        name: 'Docker & Cloud Deployment Fundamentals',
        category: 'Cloud Infrastructure',
        whyItMatters: 'Shipping code that works on your machine is no longer enough; packaging containers and deploying to Cloud Run or AWS is expected.',
        syllabusGap: 'Zero cloud infrastructure exposure in typical undergraduate syllabi.',
        estimatedHours: '20 hrs',
        freeResourceTitle: 'Docker Beginner to Pro Guide',
        freeResourceProvider: 'freeCodeCamp',
        freeResourceUrl: 'https://www.freecodecamp.org/news/tag/docker/',
        badge: 'Fast Emerging'
      }
    ]
  },
  {
    id: 'bcom',
    code: 'BCom',
    title: 'Bachelor of Commerce',
    summary: 'Moving beyond ledger books into corporate financial modeling and automated data analytics.',
    industryReality: 'Manual balance sheets on ruled paper are obsolete; top corporate finance, audit, and tax desks run completely on dynamic Excel models, Power BI, and automated GST reporting.',
    iconName: 'TrendingUp',
    skills: [
      {
        id: 'bcom-1',
        name: 'Advanced Excel & Dynamic Financial Modeling',
        category: 'Corporate Finance',
        whyItMatters: 'Every investment firm, corporate accounting team, and consultancy assesses prospective hires on XLOOKUP, INDEX/MATCH, and 3-statement models.',
        syllabusGap: 'College practical tests rarely go beyond simple SUM or AVERAGE functions on small tables.',
        estimatedHours: '35 hrs',
        freeResourceTitle: 'Financial Modeling Principles & Excel Foundations',
        freeResourceProvider: 'Corporate Finance Institute (CFI)',
        freeResourceUrl: 'https://corporatefinanceinstitute.com/resources/excel/',
        badge: 'Top Market Demand'
      },
      {
        id: 'bcom-2',
        name: 'Business Intelligence with Power BI & Tableau',
        category: 'Data Analytics',
        whyItMatters: 'Executive teams demand visual dashboarding, automated variance analysis, and interactive drill-downs over printed ledgers.',
        syllabusGap: 'Curricula emphasize static manual accounting entries with zero modern BI dashboarding.',
        estimatedHours: '30 hrs',
        freeResourceTitle: 'Microsoft Power BI Analyst Path',
        freeResourceProvider: 'Microsoft Learn',
        freeResourceUrl: 'https://learn.microsoft.com/en-us/training/powerplatform/power-bi',
        badge: 'High Growth'
      },
      {
        id: 'bcom-3',
        name: 'Practical GST, TDS Filings & Cloud Accounting (Zoho / TallyPrime)',
        category: 'Tax & Compliance',
        whyItMatters: 'SMEs and audit firms need accountants who can file GSTR-1/3B directly on live government portals and reconcile e-invoices.',
        syllabusGap: 'Academic syllabi teach taxation theory and old VAT/excise concepts without portal filing walkthroughs.',
        estimatedHours: '25 hrs',
        freeResourceTitle: 'GST Masterclass & Cloud ERP Basics',
        freeResourceProvider: 'ClearTax & Zoho Academy',
        freeResourceUrl: 'https://www.zoho.com/books/academy/',
        badge: 'Job Ready'
      },
      {
        id: 'bcom-4',
        name: 'Python for Financial Analysis & Ledger Auditing',
        category: 'FinTech',
        whyItMatters: 'Audit firms increasingly use Python and Pandas scripts to detect anomalies across millions of bank transactions automatically.',
        syllabusGap: 'No programming or data automation is included in traditional commerce curricula.',
        estimatedHours: '40 hrs',
        freeResourceTitle: 'Python for Data Analysis Crash Course',
        freeResourceProvider: 'Kaggle Learn',
        freeResourceUrl: 'https://www.kaggle.com/learn/python',
        badge: 'Future Proof'
      }
    ]
  },
  {
    id: 'bba',
    code: 'BBA',
    title: 'Bachelor of Business Administration',
    summary: 'Transforming theoretical management concepts into quantitative growth and product execution.',
    industryReality: 'Recruiters seek candidates who understand CAC, LTV, ROAS, Figma wireframing, and HubSpot pipelines—not just theoretical organizational behavior.',
    iconName: 'Briefcase',
    skills: [
      {
        id: 'bba-1',
        name: 'Performance Marketing & Growth Analytics',
        category: 'Digital Strategy',
        whyItMatters: 'Modern business growth is driven by Google/Meta Ads campaigns, A/B testing conversion funnels, and ROI attribution modeling.',
        syllabusGap: 'Textbooks focus on traditional billboard and TV advertising models instead of digital auction dynamics.',
        estimatedHours: '35 hrs',
        freeResourceTitle: 'Google Digital Marketing & Measurement Certification',
        freeResourceProvider: 'Google Skillshop',
        freeResourceUrl: 'https://skillshop.withgoogle.com/',
        badge: 'Top Market Demand'
      },
      {
        id: 'bba-2',
        name: 'Product Management & Agile Roadmapping',
        category: 'Product Strategy',
        whyItMatters: 'Entry-level associate PM and business analyst roles demand writing PRDs, running sprint standups, and mapping user journeys.',
        syllabusGap: 'Management degrees rarely teach modern software development life cycles (SDLC) or product metrics.',
        estimatedHours: '30 hrs',
        freeResourceTitle: 'Product Management Open Playbook',
        freeResourceProvider: 'Product School & Atlassian Agile',
        freeResourceUrl: 'https://www.atlassian.com/agile',
        badge: 'High Salary'
      },
      {
        id: 'bba-3',
        name: 'Sales Operations & CRM Architecture (HubSpot / Salesforce)',
        category: 'Revenue Operations',
        whyItMatters: 'High-growth startups manage thousands of inbound leads through automated lead scoring and CRM workflows.',
        syllabusGap: 'Students study theoretical negotiation rather than practical CRM pipeline operations.',
        estimatedHours: '20 hrs',
        freeResourceTitle: 'Inbound Sales & CRM Operations Certification',
        freeResourceProvider: 'HubSpot Academy',
        freeResourceUrl: 'https://academy.hubspot.com/',
        badge: 'Immediate Hire'
      },
      {
        id: 'bba-4',
        name: 'No-Code Automation (Zapier, Airtable & Make)',
        category: 'Operations',
        whyItMatters: 'Operations managers who can automate cross-department workflows without waiting on engineers save companies hundreds of hours.',
        syllabusGap: 'Completely unaddressed in academic management frameworks.',
        estimatedHours: '15 hrs',
        freeResourceTitle: 'No-Code Workflow Automation Blueprint',
        freeResourceProvider: 'Zapier University',
        freeResourceUrl: 'https://zapier.com/learn',
        badge: 'Efficiency Lever'
      }
    ]
  },
  {
    id: 'ba',
    code: 'BA',
    title: 'Bachelor of Arts',
    summary: 'Leveraging humanities, critical thinking, and storytelling into high-paying modern digital crafts.',
    industryReality: 'Humanities graduates possess exceptional research and narrative instincts; pair those with UX writing, Figma design, and SEO to command top industry compensation.',
    iconName: 'PenTool',
    skills: [
      {
        id: 'ba-1',
        name: 'UI/UX Design Systems & Interactive Prototyping (Figma)',
        category: 'Design',
        whyItMatters: 'Digital product companies need designers who understand visual psychology, typography scales, and human-computer interaction.',
        syllabusGap: 'Fine arts and literature programs rarely teach software interface design or responsive web guidelines.',
        estimatedHours: '40 hrs',
        freeResourceTitle: 'Figma for Beginners & UI Design Fundamentals',
        freeResourceProvider: 'Figma Community & Google UX Audit',
        freeResourceUrl: 'https://help.figma.com/hc/en-us/categories/360002042553-Figma-for-Beginners',
        badge: 'Top Market Demand'
      },
      {
        id: 'ba-2',
        name: 'UX Writing & Microcopy Architecture',
        category: 'Product Content',
        whyItMatters: 'Every modal, error message, and onboarding screen requires clear, concise, empathetic communication that guides users to success.',
        syllabusGap: 'College literature classes evaluate long-form essays; tech products require high-impact 3-word microcopy.',
        estimatedHours: '20 hrs',
        freeResourceTitle: 'UX Writing Foundations & Microcopy Guide',
        freeResourceProvider: 'UX Writing Hub Open Library',
        freeResourceUrl: 'https://uxwritinghub.com/free-course/',
        badge: 'Niche Advantage'
      },
      {
        id: 'ba-3',
        name: 'Technical SEO, Digital Journalism & Content Strategy',
        category: 'Marketing',
        whyItMatters: 'Publishing houses, media brands, and brands demand analytical knowledge of search intent, semantic HTML, and organic traffic growth.',
        syllabusGap: 'Academic writing focuses strictly on citations and thesis defense, ignoring algorithmic distribution and search behavior.',
        estimatedHours: '25 hrs',
        freeResourceTitle: 'The Beginner’s Guide to SEO & Content Audits',
        freeResourceProvider: 'Moz Academy & Ahrefs',
        freeResourceUrl: 'https://moz.com/beginners-guide-to-seo',
        badge: 'High Freelance Demand'
      },
      {
        id: 'ba-4',
        name: 'Generative AI Prompt Engineering & Creative Direction',
        category: 'Creative Tech',
        whyItMatters: 'Agency creative directors and content teams now use structured AI prompting for rapid mood-boarding, copywriting, and multimedia storytelling.',
        syllabusGap: 'Traditional creative curricula do not incorporate AI-assisted workflows.',
        estimatedHours: '15 hrs',
        freeResourceTitle: 'ChatGPT & Prompt Engineering for Creative Minds',
        freeResourceProvider: 'DeepLearning.AI & LearnPrompting',
        freeResourceUrl: 'https://learnprompting.org/',
        badge: 'Cutting Edge'
      }
    ]
  },
  {
    id: 'mba',
    code: 'MBA',
    title: 'Master of Business Administration',
    summary: 'Elevating generalist leadership into rigorous quantitative product analytics and AI transformation.',
    industryReality: 'Companies want leaders who can independently build financial forecasts, interpret cohort retention curves, and deploy AI operations without relying on guesswork.',
    iconName: 'Award',
    skills: [
      {
        id: 'mba-1',
        name: 'Product & Behavioral Analytics (Amplitude / Mixpanel)',
        category: 'Quantitative Strategy',
        whyItMatters: 'Executive decision-making at scale requires analyzing customer cohort retention, funnel drop-offs, and feature adoption curves.',
        syllabusGap: 'MBA case studies analyze historical decisions after the fact rather than using live behavioral telemetry.',
        estimatedHours: '30 hrs',
        freeResourceTitle: 'Mastering Retention & Cohort Analysis',
        freeResourceProvider: 'Amplitude Academy',
        freeResourceUrl: 'https://academy.amplitude.com/',
        badge: 'Leadership Critical'
      },
      {
        id: 'mba-2',
        name: 'M&A Valuation, DCF & LBO Financial Modeling',
        category: 'Investment Strategy',
        whyItMatters: 'Investment banking, PE, and corporate VC roles require creating institutional-grade valuation models under tight deadlines.',
        syllabusGap: 'Classroom finance courses review formulas on slides without building functional multi-sheet dynamic models from scratch.',
        estimatedHours: '40 hrs',
        freeResourceTitle: 'Valuation & Corporate Finance Open Lectures',
        freeResourceProvider: 'Prof. Aswath Damodaran (NYU Stern)',
        freeResourceUrl: 'https://pages.stern.nyu.edu/~adamodar/',
        badge: 'Wall Street Standard'
      },
      {
        id: 'mba-3',
        name: 'Scrum Leadership & Modern Sprint Delivery',
        category: 'Operations',
        whyItMatters: 'Bridging strategy to execution demands running agile ceremonies, managing sprint velocity, and unblocking engineering hurdles.',
        syllabusGap: 'Curricula teach old waterfall Gantt charts rather than modern continuous deployment cycles.',
        estimatedHours: '20 hrs',
        freeResourceTitle: 'Agile at Scale Playbook & Scrum Guide',
        freeResourceProvider: 'Scrum.org & Atlassian',
        freeResourceUrl: 'https://www.scrum.org/open-assessments',
        badge: 'Execution Driver'
      },
      {
        id: 'mba-4',
        name: 'Enterprise AI Strategy & ROI Assessment',
        category: 'Strategic Tech',
        whyItMatters: 'Boardrooms need leaders who can evaluate which internal processes should be automated, manage governance, and calculate net cost-benefit.',
        syllabusGap: 'Most graduate business schools lack courses on applied corporate AI economics and deployment risks.',
        estimatedHours: '25 hrs',
        freeResourceTitle: 'AI for Business Strategy & Operations',
        freeResourceProvider: 'Google Cloud & MIT Sloan Open',
        freeResourceUrl: 'https://www.cloudskillsboost.google/',
        badge: 'Executive Level'
      }
    ]
  }
];
