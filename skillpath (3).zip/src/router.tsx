import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { UserAuth } from './types';

interface RouterContextType {
  path: string;
  navigate: (to: string) => void;
  user: UserAuth;
  loginWithGoogle: () => Promise<void>;
  loginWithEmail: (email: string) => Promise<void>;
  signupWithEmail: (name: string, email: string) => Promise<void>;
  logout: () => void;
  hasSeenIntro: boolean;
  setHasSeenIntro: (seen: boolean) => void;
  replayIntro: () => void;
}

const RouterContext = createContext<RouterContextType | undefined>(undefined);

const ROUTE_TITLES: Record<string, string> = {
  '/': 'SkillPath — Skill Clarity for the Modern Student',
  '/find-gap': 'SkillPath — Find My Gap',
  '/how-it-works': 'SkillPath — How It Works',
  '/about': 'SkillPath — About Us',
  '/login': 'SkillPath — Login',
  '/signup': 'SkillPath — Sign Up',
  '/contact': 'SkillPath — Contact',
};

export const RouterProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [path, setPath] = useState<string>(() => {
    if (typeof window !== 'undefined') {
      return window.location.pathname || '/';
    }
    return '/';
  });

  const [hasSeenIntro, setHasSeenIntroState] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      return sessionStorage.getItem('skillpath_intro_passed') === 'true';
    }
    return false;
  });

  const [user, setUser] = useState<UserAuth>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('skillpath_mock_user');
      if (saved) {
        try {
          return JSON.parse(saved);
        } catch {
          // ignore
        }
      }
    }
    return { isLoggedIn: false };
  });

  const setHasSeenIntro = (seen: boolean) => {
    setHasSeenIntroState(seen);
    if (typeof window !== 'undefined') {
      if (seen) {
        sessionStorage.setItem('skillpath_intro_passed', 'true');
      } else {
        sessionStorage.removeItem('skillpath_intro_passed');
      }
    }
  };

  const replayIntro = () => {
    setHasSeenIntro(false);
    navigate('/');
  };

  const navigate = (to: string) => {
    if (to === path) {
      window.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }
    window.history.pushState({}, '', to);
    setPath(to);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  useEffect(() => {
    const handlePopState = () => {
      setPath(window.location.pathname || '/');
    };
    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  useEffect(() => {
    const title = ROUTE_TITLES[path] || 'SkillPath — Page Not Found';
    document.title = title;
  }, [path]);

  const loginWithGoogle = async () => {
    // Simulate short network delay
    await new Promise((res) => setTimeout(res, 1000));
    const mockUser: UserAuth = {
      isLoggedIn: true,
      name: 'Alex Rivera',
      email: 'alex.rivera@college.edu',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop&q=80',
      provider: 'google',
    };
    setUser(mockUser);
    localStorage.setItem('skillpath_mock_user', JSON.stringify(mockUser));
  };

  const loginWithEmail = async (email: string) => {
    await new Promise((res) => setTimeout(res, 1000));
    const nameFromEmail = email.split('@')[0] || 'Student';
    const mockUser: UserAuth = {
      isLoggedIn: true,
      name: nameFromEmail.charAt(0).toUpperCase() + nameFromEmail.slice(1),
      email,
      provider: 'email',
    };
    setUser(mockUser);
    localStorage.setItem('skillpath_mock_user', JSON.stringify(mockUser));
  };

  const signupWithEmail = async (name: string, email: string) => {
    await new Promise((res) => setTimeout(res, 1000));
    const mockUser: UserAuth = {
      isLoggedIn: true,
      name,
      email,
      provider: 'email',
    };
    setUser(mockUser);
    localStorage.setItem('skillpath_mock_user', JSON.stringify(mockUser));
  };

  const logout = () => {
    setUser({ isLoggedIn: false });
    localStorage.removeItem('skillpath_mock_user');
  };

  return (
    <RouterContext.Provider
      value={{
        path,
        navigate,
        user,
        loginWithGoogle,
        loginWithEmail,
        signupWithEmail,
        logout,
        hasSeenIntro,
        setHasSeenIntro,
        replayIntro,
      }}
    >
      {children}
    </RouterContext.Provider>
  );
};

export const useRouter = () => {
  const context = useContext(RouterContext);
  if (!context) {
    throw new Error('useRouter must be used within a RouterProvider');
  }
  return context;
};

interface LinkProps extends React.AnchorHTMLAttributes<HTMLAnchorElement> {
  to: string;
  children: ReactNode;
  activeClassName?: string;
  className?: string;
  id?: string;
}

export const Link: React.FC<LinkProps> = ({
  to,
  children,
  className = '',
  activeClassName = '',
  onClick,
  id,
  ...props
}) => {
  const { path, navigate } = useRouter();
  const isActive = path === to;

  const handleClick = (e: React.MouseEvent<HTMLAnchorElement>) => {
    e.preventDefault();
    if (onClick) {
      onClick(e);
    }
    navigate(to);
  };

  const combinedClass = `${className} ${isActive ? activeClassName : ''}`.trim();

  return (
    <a
      id={id}
      href={to}
      onClick={handleClick}
      className={combinedClass}
      aria-current={isActive ? 'page' : undefined}
      {...props}
    >
      {children}
    </a>
  );
};
