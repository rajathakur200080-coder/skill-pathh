export interface Skill {
  id: string;
  name: string;
  category: string;
  whyItMatters: string;
  syllabusGap: string;
  estimatedHours: string;
  freeResourceTitle: string;
  freeResourceProvider: string;
  freeResourceUrl: string;
  badge: string;
}

export interface DegreeData {
  id: string;
  code: string;
  title: string;
  summary: string;
  industryReality: string;
  iconName: string;
  skills: Skill[];
}

export interface UserAuth {
  isLoggedIn: boolean;
  name?: string;
  email?: string;
  avatar?: string;
  provider?: 'google' | 'email';
}
