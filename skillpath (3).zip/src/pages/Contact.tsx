import React, { useState } from 'react';
import { Mail, User, MessageSquare, Send, CheckCircle2, AlertCircle, Loader2, Sparkles } from 'lucide-react';

export const Contact: React.FC = () => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');
  const [errors, setErrors] = useState<{ name?: string; email?: string; message?: string }>({});
  const [isLoading, setIsLoading] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  const validate = () => {
    const newErrors: { name?: string; email?: string; message?: string } = {};

    if (!name.trim()) {
      newErrors.name = 'Please provide your name.';
    }

    if (!email.trim()) {
      newErrors.email = 'Please provide your email address.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
      newErrors.email = 'Please enter a valid email format (e.g. name@domain.com).';
    }

    if (!message.trim()) {
      newErrors.message = 'Please type your message.';
    } else if (message.trim().length < 10) {
      newErrors.message = 'Message must be at least 10 characters long.';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    setIsLoading(true);

    // Simulate 1s server processing
    await new Promise((resolve) => setTimeout(resolve, 1000));
    setIsLoading(false);
    setIsSuccess(true);
  };

  const handleReset = () => {
    setName('');
    setEmail('');
    setMessage('');
    setErrors({});
    setIsSuccess(false);
  };

  return (
    <div className="w-full py-12 sm:py-20">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-2xl mx-auto mb-12">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white/5 border border-white/10 text-xs font-medium text-[#4361ee] mb-4">
            <Sparkles className="w-3.5 h-3.5 text-[#4361ee]" />
            <span>Student Support & Degree Suggestions</span>
          </div>

          <h1 className="text-3xl sm:text-5xl font-extrabold text-white tracking-tight mb-4">
            Get in{' '}
            <span className="bg-gradient-to-r from-[#4361ee] to-[#f72585] bg-clip-text text-transparent">
              Touch
            </span>
          </h1>

          <p className="text-base text-[#a0a4c1]">
            Have a question about a skill roadmap, want to suggest your college degree, or recommend an open-source course? We’d love to hear from you.
          </p>
        </div>

        {/* Contact Form Box */}
        <div className="rounded-3xl bg-[#0a0e27] border border-white/10 p-8 sm:p-12 shadow-2xl relative overflow-hidden">
          {/* Decorative ambient flare */}
          <div className="absolute top-0 right-0 w-64 h-64 bg-[#f72585]/10 rounded-full blur-3xl pointer-events-none" />

          {isSuccess ? (
            /* Success confirmation card */
            <div
              id="contact-success-state"
              className="py-12 text-center flex flex-col items-center justify-center animate-in fade-in duration-300"
            >
              <div className="w-16 h-16 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center mb-6 shadow-lg shadow-emerald-500/10">
                <CheckCircle2 className="w-8 h-8" />
              </div>
              <h2 className="text-2xl sm:text-3xl font-bold text-white mb-2">
                Thank you, we'll get back to you!
              </h2>
              <p className="text-sm sm:text-base text-[#a0a4c1] max-w-md mx-auto mb-8">
                Your message has been received by our student curriculum research team. We typically respond within 24 hours.
              </p>
              <button
                type="button"
                id="contact-send-another-btn"
                onClick={handleReset}
                className="px-6 py-3 rounded-full text-xs font-semibold text-white bg-white/10 hover:bg-white/20 transition-colors cursor-pointer"
              >
                Send Another Message
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} noValidate className="space-y-6 relative z-10">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                {/* Name */}
                <div>
                  <label
                    htmlFor="contact-name"
                    className="block text-xs font-semibold uppercase tracking-wider text-[#a0a4c1] mb-2"
                  >
                    Your Name
                  </label>
                  <div className="relative">
                    <User className="w-4 h-4 text-[#a0a4c1] absolute left-3.5 top-1/2 -translate-y-1/2" />
                    <input
                      id="contact-name"
                      type="text"
                      autoComplete="name"
                      value={name}
                      onChange={(e) => {
                        setName(e.target.value);
                        if (errors.name) setErrors((prev) => ({ ...prev, name: undefined }));
                      }}
                      placeholder="e.g. Alex Rivera"
                      className={`w-full bg-[#060815] border rounded-xl pl-10 pr-4 py-3 text-sm text-white placeholder-[#a0a4c1]/60 focus:outline-none transition-colors ${
                        errors.name
                          ? 'border-red-500 focus:ring-1 focus:ring-red-500'
                          : 'border-white/15 focus:border-[#4361ee]'
                      }`}
                    />
                  </div>
                  {errors.name && (
                    <p id="contact-name-error" className="mt-1.5 text-xs text-red-400 flex items-center gap-1">
                      <AlertCircle className="w-3 h-3" />
                      <span>{errors.name}</span>
                    </p>
                  )}
                </div>

                {/* Email */}
                <div>
                  <label
                    htmlFor="contact-email"
                    className="block text-xs font-semibold uppercase tracking-wider text-[#a0a4c1] mb-2"
                  >
                    Email Address
                  </label>
                  <div className="relative">
                    <Mail className="w-4 h-4 text-[#a0a4c1] absolute left-3.5 top-1/2 -translate-y-1/2" />
                    <input
                      id="contact-email"
                      type="email"
                      autoComplete="email"
                      value={email}
                      onChange={(e) => {
                        setEmail(e.target.value);
                        if (errors.email) setErrors((prev) => ({ ...prev, email: undefined }));
                      }}
                      placeholder="name@college.edu"
                      className={`w-full bg-[#060815] border rounded-xl pl-10 pr-4 py-3 text-sm text-white placeholder-[#a0a4c1]/60 focus:outline-none transition-colors ${
                        errors.email
                          ? 'border-red-500 focus:ring-1 focus:ring-red-500'
                          : 'border-white/15 focus:border-[#4361ee]'
                      }`}
                    />
                  </div>
                  {errors.email && (
                    <p id="contact-email-error" className="mt-1.5 text-xs text-red-400 flex items-center gap-1">
                      <AlertCircle className="w-3 h-3" />
                      <span>{errors.email}</span>
                    </p>
                  )}
                </div>
              </div>

              {/* Message */}
              <div>
                <label
                  htmlFor="contact-message"
                  className="block text-xs font-semibold uppercase tracking-wider text-[#a0a4c1] mb-2"
                >
                  Message or Degree Feedback
                </label>
                <div className="relative">
                  <textarea
                    id="contact-message"
                    rows={5}
                    value={message}
                    onChange={(e) => {
                      setMessage(e.target.value);
                      if (errors.message) setErrors((prev) => ({ ...prev, message: undefined }));
                    }}
                    placeholder="Tell us what degree track you'd like added or what skills your college didn't teach you..."
                    className={`w-full bg-[#060815] border rounded-xl p-3.5 text-sm text-white placeholder-[#a0a4c1]/60 focus:outline-none transition-colors resize-y ${
                      errors.message
                        ? 'border-red-500 focus:ring-1 focus:ring-red-500'
                        : 'border-white/15 focus:border-[#4361ee]'
                    }`}
                  />
                </div>
                {errors.message && (
                  <p id="contact-message-error" className="mt-1.5 text-xs text-red-400 flex items-center gap-1">
                    <AlertCircle className="w-3 h-3" />
                    <span>{errors.message}</span>
                  </p>
                )}
              </div>

              {/* Submit button with loading state */}
              <div className="flex justify-end">
                <button
                  type="submit"
                  id="contact-submit-btn"
                  disabled={isLoading}
                  className="inline-flex items-center justify-center gap-2 px-8 py-3.5 rounded-full font-semibold text-white bg-gradient-to-r from-[#4361ee] to-[#f72585] hover:opacity-95 shadow-lg shadow-[#4361ee]/20 hover:scale-[1.02] active:scale-[0.98] transition-all cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed focus:outline-none focus:ring-2 focus:ring-[#f72585]"
                >
                  {isLoading ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span>Sending...</span>
                    </>
                  ) : (
                    <>
                      <span>Send Message</span>
                      <Send className="w-4 h-4" />
                    </>
                  )}
                </button>
              </div>
            </form>
          )}

        </div>

      </div>
    </div>
  );
};
