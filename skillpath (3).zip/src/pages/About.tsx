import React from 'react';
import { Link } from '../router';
import {
  Compass,
  Sparkles,
  CheckCircle,
  Eye,
  Unlock,
  BarChart3,
  ArrowRight,
  GraduationCap,
  Users,
} from 'lucide-react';

export const About: React.FC = () => {
  const values = [
    {
      title: 'Clarity',
      subtitle: 'Zero fluff, zero vague roadmaps',
      description:
        'We replace overwhelming 200-item skill checklists with concise, decisive 4–5 core competencies that actually shift the needle in interviews.',
      icon: Eye,
      accent: 'text-[#4361ee]',
      bg: 'bg-[#4361ee]/15',
    },
    {
      title: 'Accessibility',
      subtitle: '100% free educational resources',
      description:
        'World-class higher learning should never be locked behind expensive predatory tuition. Every recommendation links directly to verified free courses.',
      icon: Unlock,
      accent: 'text-[#f72585]',
      bg: 'bg-[#f72585]/15',
    },
    {
      title: 'Real Industry Data',
      subtitle: 'Grounded in active job openings',
      description:
        'We reject outdated textbook theory. Our skill mappings are extracted directly from active recruiter hiring criteria and engineering team expectations.',
      icon: BarChart3,
      accent: 'text-emerald-400',
      bg: 'bg-emerald-500/15',
    },
  ];

  return (
    <div className="w-full py-12 sm:py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header / Mission Statement */}
        <div className="text-center max-w-3xl mx-auto mb-16 sm:mb-20">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white/5 border border-white/10 text-xs font-medium text-[#f72585] mb-4">
            <Compass className="w-3.5 h-3.5 text-[#f72585]" />
            <span>Our Purpose</span>
          </div>

          <h1 className="text-3xl sm:text-5xl font-extrabold text-white tracking-tight mb-6">
            Skill Clarity for the Modern Student
          </h1>

          {/* Mission statement */}
          <p className="text-lg sm:text-xl text-white font-medium leading-relaxed max-w-2xl mx-auto">
            Our mission is to eliminate the anxiety of graduation by giving every college student the transparent truth about industry demand — and the zero-cost tools to meet it.
          </p>
        </div>

        {/* Our Story Paragraph */}
        <div className="max-w-4xl mx-auto rounded-3xl bg-[#0a0e27] border border-white/10 p-8 sm:p-12 mb-20 shadow-xl">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#4361ee] to-[#f72585] flex items-center justify-center text-white font-bold">
              S
            </div>
            <div>
              <h2 className="text-xl font-bold text-white">Our Story</h2>
              <p className="text-xs text-[#a0a4c1]">Born out of real student frustration</p>
            </div>
          </div>

          <div className="space-y-4 text-sm sm:text-base text-[#a0a4c1] leading-relaxed">
            <p>
              In colleges across the world, brilliant students spend three to four years mastering handwritten syntax, theoretical commerce debits, and textbook case studies — only to face crushing rejection when applying for modern entry-level roles.
            </p>
            <p>
              When we audited standard university syllabi across BCA, BCom, BBA, BA, and MBA programs, the issue became painfully obvious: academic curricula evolve every 8–10 years, whereas tech stacks and corporate workflows evolve every 18 months.
            </p>
            <p className="text-white font-medium">
              SkillPath was created as the definitive bridge. Instead of charging students thousands of dollars for bootcamps, we curate the world’s best open educational resources — from Harvard’s CS50 to Microsoft Learn and open source communities — organizing them by degree into actionable, stress-free roadmaps.
            </p>
          </div>

          {/* Key metrics row */}
          <div className="mt-8 pt-8 border-t border-white/10 grid grid-cols-3 gap-4 text-center">
            <div>
              <div className="text-2xl sm:text-3xl font-extrabold text-white">300+</div>
              <div className="text-xs text-[#a0a4c1] mt-1">Students Guided</div>
            </div>
            <div>
              <div className="text-2xl sm:text-3xl font-extrabold text-white">5+</div>
              <div className="text-xs text-[#a0a4c1] mt-1">Degrees Mapped</div>
            </div>
            <div>
              <div className="text-2xl sm:text-3xl font-extrabold text-emerald-400">100%</div>
              <div className="text-xs text-[#a0a4c1] mt-1">Free Courses</div>
            </div>
          </div>
        </div>

        {/* 3 Simple Value Cards */}
        <div className="max-w-5xl mx-auto mb-20">
          <div className="text-center mb-12">
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight mb-3">
              Our Core Values
            </h2>
            <p className="text-sm text-[#a0a4c1]">
              The principles behind every skill gap recommendation and curriculum curation.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 sm:gap-8">
            {values.map((val) => {
              const Icon = val.icon;
              return (
                <div
                  key={val.title}
                  id={`value-card-${val.title.toLowerCase().replace(/\s+/g, '-')}`}
                  className="rounded-2xl bg-[#0a0e27] border border-white/10 p-7 flex flex-col hover:border-white/20 transition-all duration-200"
                >
                  <div
                    className={`w-12 h-12 rounded-xl ${val.bg} ${val.accent} flex items-center justify-center mb-5`}
                  >
                    <Icon className="w-6 h-6" />
                  </div>

                  <h3 className="text-xl font-bold text-white mb-1">
                    {val.title}
                  </h3>

                  <div className="text-xs font-medium text-[#a0a4c1] mb-3">
                    {val.subtitle}
                  </div>

                  <p className="text-sm text-[#a0a4c1] leading-relaxed">
                    {val.description}
                  </p>
                </div>
              );
            })}
          </div>
        </div>

        {/* Call to action */}
        <div className="text-center py-8">
          <Link
            to="/find-gap"
            id="about-cta-btn"
            className="inline-flex items-center gap-2 px-8 py-3.5 rounded-full font-semibold text-white bg-gradient-to-r from-[#4361ee] to-[#f72585] shadow-lg shadow-[#4361ee]/25 hover:scale-[1.02] active:scale-[0.98] transition-all"
          >
            <span>Explore Your Degree Gaps</span>
            <ArrowRight className="w-4 h-4" />
          </Link>
        </div>

      </div>
    </div>
  );
};
