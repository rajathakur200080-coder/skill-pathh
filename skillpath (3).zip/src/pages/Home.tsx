import React, { useState } from 'react';
import { useRouter, Link } from '../router';
import {
  ArrowRight,
  Sparkles,
  BookOpen,
  Search,
  CheckCircle2,
  TrendingUp,
  GraduationCap,
  Layers,
  ArrowUpRight,
  ShieldCheck,
  Zap,
} from 'lucide-react';

export const Home: React.FC = () => {
  const { navigate } = useRouter();
  const [videoError, setVideoError] = useState(false);

  return (
    <div className="w-full flex flex-col">
      {/* ============================================================ */}
      {/* HERO SECTION                                                 */}
      {/* ============================================================ */}
      <section
        id="hero-section"
        className="relative pt-8 pb-20 sm:pt-14 sm:pb-28 overflow-hidden"
      >
        {/* Ambient atmospheric glow in background */}
        <div className="absolute top-0 left-1/4 -translate-x-1/2 w-[550px] h-[550px] bg-[#4361ee]/15 rounded-full blur-3xl pointer-events-none -z-10" />
        <div className="absolute top-1/3 right-10 w-[450px] h-[450px] bg-[#f72585]/12 rounded-full blur-3xl pointer-events-none -z-10" />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 min-[900px]:grid-cols-12 gap-12 lg:gap-16 items-center">
            
            {/* LEFT COLUMN: Hero copy & CTAs */}
            <div className="min-[900px]:col-span-7 flex flex-col items-start text-left animate-in fade-in slide-in-from-bottom-6 duration-700">
              
              {/* Eyebrow text */}
              <div
                id="hero-eyebrow"
                className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white/[0.06] border border-white/10 text-xs sm:text-sm font-medium text-[#f5f6fa] mb-6 shadow-sm"
              >
                <Sparkles className="w-3.5 h-3.5 text-[#f72585]" />
                <span>Skill Clarity for the Modern Student</span>
              </div>

              {/* Headline */}
              <h1
                id="hero-headline"
                className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-white leading-[1.12] mb-6"
              >
                Turn Ambition Into{' '}
                <span className="bg-gradient-to-r from-[#4361ee] to-[#f72585] bg-clip-text text-transparent">
                  Your Skill Path.
                </span>
              </h1>

              {/* Subheadline */}
              <p
                id="hero-subheadline"
                className="text-base sm:text-lg text-[#a0a4c1] max-w-xl leading-relaxed mb-8"
              >
                Pick your degree to instantly see the real-world skills employers require that college never taught you — and exactly where to master them for free.
              </p>

              {/* CTA Row */}
              <div className="flex flex-wrap items-center gap-4 sm:gap-6 mb-12">
                <Link
                  to="/find-gap"
                  id="hero-cta-get-started"
                  className="inline-flex items-center gap-2.5 px-7 py-3.5 rounded-full font-semibold text-white bg-gradient-to-r from-[#4361ee] to-[#f72585] hover:opacity-95 shadow-lg shadow-[#4361ee]/25 hover:shadow-[#f72585]/30 hover:scale-[1.02] active:scale-[0.98] transition-all duration-200"
                >
                  <span>Get Started</span>
                  <ArrowRight className="w-4 h-4" />
                </Link>

                <Link
                  to="/how-it-works"
                  id="hero-cta-how-it-works"
                  className="inline-flex items-center gap-1.5 text-sm font-medium text-[#a0a4c1] hover:text-white transition-colors duration-200 group py-2"
                >
                  <span>See How It Works</span>
                  <ArrowUpRight className="w-4 h-4 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform duration-200" />
                </Link>
              </div>

              {/* Stats Row */}
              <div
                id="hero-stats-row"
                className="w-full pt-8 border-t border-white/[0.08] grid grid-cols-3 gap-3 sm:gap-6"
              >
                <div>
                  <div className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
                    300+
                  </div>
                  <div className="text-xs sm:text-sm text-[#a0a4c1] mt-0.5">
                    Students Guided
                  </div>
                </div>

                <div className="border-l border-white/[0.08] pl-3 sm:pl-6">
                  <div className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
                    5+
                  </div>
                  <div className="text-xs sm:text-sm text-[#a0a4c1] mt-0.5">
                    Degree Paths Covered
                  </div>
                </div>

                <div className="border-l border-white/[0.08] pl-3 sm:pl-6">
                  <div className="text-2xl sm:text-3xl font-extrabold text-emerald-400 tracking-tight">
                    100%
                  </div>
                  <div className="text-xs sm:text-sm text-[#a0a4c1] mt-0.5">
                    Free Resources
                  </div>
                </div>
              </div>

            </div>

            {/* RIGHT COLUMN: Video panel with glassy ring decoration */}
            <div className="min-[900px]:col-span-5 flex justify-center animate-in fade-in slide-in-from-bottom-8 duration-900 delay-150">
              <div className="relative w-full max-w-[380px] sm:max-w-[420px] aspect-[4/5] flex items-center justify-center">
                
                {/* Glassy ring decoration behind video panel */}
                <div className="absolute inset-[-12px] sm:inset-[-18px] rounded-[32px] border border-white/10 bg-gradient-to-tr from-[#4361ee]/20 via-transparent to-[#f72585]/20 backdrop-blur-xl -z-10 animate-pulse-glow" />
                <div className="absolute inset-[-28px] rounded-[40px] border border-white/[0.04] pointer-events-none -z-20" />

                {/* Video container */}
                <div className="w-full h-full rounded-2xl overflow-hidden bg-[#070a1e] border border-white/15 shadow-2xl shadow-black/80 relative group">
                  {!videoError ? (
                    <video
                      id="hero-video-player"
                      src="https://res.cloudinary.com/danwjkgw/video/upload/v1789192134/Animate_silhouette_image_with_mo__20260912111604.mp4"
                      autoPlay
                      loop
                      muted
                      playsInline
                      onError={() => setVideoError(true)}
                      className="w-full h-full object-cover select-none"
                    />
                  ) : (
                    /* Elegant fallback if video URL is unreachable */
                    <div className="w-full h-full flex flex-col items-center justify-center p-6 text-center bg-gradient-to-br from-[#0c1236] to-[#060815]">
                      <GraduationCap className="w-16 h-16 text-[#4361ee] mb-4" />
                      <div className="text-lg font-bold text-white mb-2">
                        Industry Skill Roadmap
                      </div>
                      <p className="text-xs text-[#a0a4c1]">
                        Visualizing degree curricula against real-world engineering and business demands.
                      </p>
                    </div>
                  )}

                  {/* Glassy status pill overlay */}
                  <div className="absolute bottom-4 left-4 right-4 p-3 rounded-xl bg-[#060815]/80 backdrop-blur-md border border-white/10 flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                      <span className="text-xs font-medium text-white">Live Curriculum Mapper</span>
                    </div>
                    <span className="text-[11px] font-mono text-[#f72585] font-semibold">2026 Ready</span>
                  </div>
                </div>

              </div>
            </div>

          </div>
        </div>
      </section>


      {/* ============================================================ */}
      {/* WHY SKILLPATH SECTION                                         */}
      {/* 2-3 lines explaining mission + one supporting graphic        */}
      {/* ============================================================ */}
      <section
        id="why-skillpath-section"
        className="py-20 bg-[#080c20]/60 border-y border-white/[0.06] relative"
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="text-center max-w-3xl mx-auto mb-14">
            <div className="inline-flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-[#4361ee] mb-3">
              <Zap className="w-3.5 h-3.5" />
              <span>The Problem We Solve</span>
            </div>
            
            <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight mb-4">
              Why SkillPath?
            </h2>

            {/* 2-3 lines explaining the mission */}
            <p className="text-base sm:text-lg text-[#a0a4c1] leading-relaxed">
              Traditional college degrees prepare you for 20th-century theory exams, but hiring managers recruit for live production tools, frameworks, and financial workflows. SkillPath pinpoints your degree's exact blind spots and hands you curated, free roadmaps to graduate ahead of the competition.
            </p>
          </div>

          {/* Supporting Graphic: College Syllabus vs Industry Reality Interactive Comparison */}
          <div className="max-w-4xl mx-auto rounded-2xl bg-[#0a0e27] border border-white/10 p-6 sm:p-8 shadow-xl">
            <div className="flex items-center justify-between pb-6 border-b border-white/10">
              <div className="flex items-center gap-2">
                <Layers className="w-5 h-5 text-[#f72585]" />
                <h3 className="text-lg font-bold text-white">
                  The Degree Gap Analysis
                </h3>
              </div>
              <span className="text-xs text-[#a0a4c1] hidden sm:inline">
                Analyzed across 1,000+ entry-level job descriptions
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
              {/* College Syllabus Box */}
              <div className="p-5 rounded-xl bg-white/[0.02] border border-red-500/20 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-xs font-semibold uppercase text-red-400">
                      Standard College Syllabus
                    </span>
                    <span className="text-[11px] px-2 py-0.5 rounded bg-red-500/10 text-red-300">
                      Outdated Focus
                    </span>
                  </div>
                  <ul className="space-y-2.5 text-sm text-[#a0a4c1]">
                    <li className="flex items-start gap-2">
                      <span className="text-red-400 mt-0.5">&times;</span>
                      <span>Handwritten code and syntax memorization on lined paper</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-red-400 mt-0.5">&times;</span>
                      <span>Manual ledger balance sheets and old accounting books</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-red-400 mt-0.5">&times;</span>
                      <span>Theoretical essay writing without digital channel metrics</span>
                    </li>
                  </ul>
                </div>
                <div className="mt-4 pt-3 border-t border-white/5 text-xs text-red-300/80">
                  Result: Graduates face intense rejection for lack of practical experience.
                </div>
              </div>

              {/* Industry Stack Box */}
              <div className="p-5 rounded-xl bg-gradient-to-br from-[#4361ee]/10 to-[#f72585]/10 border border-[#4361ee]/30 flex flex-col justify-between shadow-lg">
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-xs font-semibold uppercase text-[#f72585]">
                      The Industry Stack
                    </span>
                    <span className="text-[11px] px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-300">
                      What Companies Pay For
                    </span>
                  </div>
                  <ul className="space-y-2.5 text-sm text-white">
                    <li className="flex items-start gap-2">
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                      <span>Git PR reviews, React components, and Docker containers</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                      <span>Dynamic 3-statement financial modeling & Power BI dashboards</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                      <span>UX microcopy, Figma wireframing & conversion analytics</span>
                    </li>
                  </ul>
                </div>
                <div className="mt-4 pt-3 border-t border-white/10 text-xs text-emerald-400 font-medium">
                  SkillPath Fix: We provide 100% free courses to close this gap completely.
                </div>
              </div>
            </div>

            <div className="mt-6 pt-6 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-4">
              <span className="text-xs text-[#a0a4c1]">
                Zero tuition fees. No credit cards required. Only top-tier open learning platforms.
              </span>
              <Link
                to="/find-gap"
                className="text-xs font-semibold text-white bg-white/10 hover:bg-white/15 px-4 py-2 rounded-lg transition-colors flex items-center gap-1.5"
              >
                <span>Check Your Degree</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </Link>
            </div>
          </div>

        </div>
      </section>


      {/* ============================================================ */}
      {/* 3-STEP "HOW IT WORKS" PREVIEW SECTION                         */}
      {/* (Pick Degree → See Skill Gaps → Learn Free)                  */}
      {/* ============================================================ */}
      <section id="how-it-works-preview" className="py-20 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="text-center max-w-2xl mx-auto mb-16">
            <div className="inline-flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-[#f72585] mb-3">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Simple 3-Step Process</span>
            </div>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight mb-4">
              How SkillPath Works
            </h2>
            <p className="text-base text-[#a0a4c1]">
              A frictionless pathway designed specifically for busy college students.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            
            {/* Step 1 */}
            <div className="group p-6 rounded-2xl bg-[#0a0e27] border border-white/10 hover:border-[#4361ee]/40 transition-all duration-300 flex flex-col">
              <div className="w-12 h-12 rounded-xl bg-[#4361ee]/15 text-[#4361ee] flex items-center justify-center text-lg font-bold mb-5 group-hover:scale-110 transition-transform duration-200">
                01
              </div>
              <h3 className="text-xl font-bold text-white mb-2">
                Pick Your Degree
              </h3>
              <p className="text-sm text-[#a0a4c1] leading-relaxed mb-4">
                Select your undergraduate or master’s program — whether it’s BCA, BCom, BBA, BA, or MBA.
              </p>
              <div className="mt-auto pt-4 border-t border-white/5 flex items-center gap-2 text-xs text-[#4361ee] font-medium">
                <GraduationCap className="w-4 h-4" />
                <span>5 specialized paths</span>
              </div>
            </div>

            {/* Step 2 */}
            <div className="group p-6 rounded-2xl bg-[#0a0e27] border border-white/10 hover:border-[#f72585]/40 transition-all duration-300 flex flex-col">
              <div className="w-12 h-12 rounded-xl bg-[#f72585]/15 text-[#f72585] flex items-center justify-center text-lg font-bold mb-5 group-hover:scale-110 transition-transform duration-200">
                02
              </div>
              <h3 className="text-xl font-bold text-white mb-2">
                See Skill Gaps
              </h3>
              <p className="text-sm text-[#a0a4c1] leading-relaxed mb-4">
                Instantly view the top 4–5 practical competencies employers demand that university curricula ignore.
              </p>
              <div className="mt-auto pt-4 border-t border-white/5 flex items-center gap-2 text-xs text-[#f72585] font-medium">
                <Search className="w-4 h-4" />
                <span>Live market data</span>
              </div>
            </div>

            {/* Step 3 */}
            <div className="group p-6 rounded-2xl bg-[#0a0e27] border border-white/10 hover:border-emerald-500/40 transition-all duration-300 flex flex-col">
              <div className="w-12 h-12 rounded-xl bg-emerald-500/15 text-emerald-400 flex items-center justify-center text-lg font-bold mb-5 group-hover:scale-110 transition-transform duration-200">
                03
              </div>
              <h3 className="text-xl font-bold text-white mb-2">
                Learn For Free
              </h3>
              <p className="text-sm text-[#a0a4c1] leading-relaxed mb-4">
                Launch directly into verified, free masterclasses from Harvard, Microsoft, CFI, and open source guides.
              </p>
              <div className="mt-auto pt-4 border-t border-white/5 flex items-center gap-2 text-xs text-emerald-400 font-medium">
                <CheckCircle2 className="w-4 h-4" />
                <span>Zero cost learning</span>
              </div>
            </div>

          </div>

          <div className="mt-12 text-center">
            <Link
              to="/how-it-works"
              className="inline-flex items-center gap-2 text-sm font-semibold text-white hover:text-[#4361ee] transition-colors"
            >
              <span>Explore the complete breakdown</span>
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>

        </div>
      </section>


      {/* ============================================================ */}
      {/* CTA BANNER                                                   */}
      {/* ("Ready to find your path?" + Get Started button)            */}
      {/* ============================================================ */}
      <section id="cta-banner" className="py-16 sm:py-20">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="relative rounded-3xl overflow-hidden bg-gradient-to-r from-[#0e1438] via-[#141b4d] to-[#0e1438] border border-white/15 p-8 sm:p-12 text-center shadow-2xl">
            
            {/* Background glow flares */}
            <div className="absolute -top-24 -left-24 w-60 h-60 bg-[#4361ee]/30 rounded-full blur-3xl pointer-events-none" />
            <div className="absolute -bottom-24 -right-24 w-60 h-60 bg-[#f72585]/30 rounded-full blur-3xl pointer-events-none" />

            <div className="relative z-10 max-w-2xl mx-auto">
              <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight mb-4">
                Ready to find your path?
              </h2>
              <p className="text-base sm:text-lg text-[#a0a4c1] mb-8 leading-relaxed">
                Join hundreds of college students taking charge of their career readiness. Zero signup required to explore your degree gaps.
              </p>
              <div className="flex flex-wrap items-center justify-center gap-4">
                <Link
                  to="/find-gap"
                  id="cta-banner-get-started"
                  className="inline-flex items-center gap-2 px-8 py-3.5 rounded-full font-semibold text-white bg-gradient-to-r from-[#4361ee] to-[#f72585] hover:opacity-95 shadow-lg shadow-[#4361ee]/30 hover:scale-[1.02] active:scale-[0.98] transition-all duration-200"
                >
                  <span>Get Started Now</span>
                  <ArrowRight className="w-4 h-4" />
                </Link>
                <Link
                  to="/about"
                  className="px-6 py-3.5 rounded-full font-medium text-white border border-white/20 hover:bg-white/10 transition-colors"
                >
                  Our Mission
                </Link>
              </div>
            </div>

          </div>
        </div>
      </section>

    </div>
  );
};
