import React from 'react';
import { Link } from '../router';
import { Compass, Home, ArrowLeft } from 'lucide-react';

export const NotFound: React.FC = () => {
  return (
    <div className="w-full min-h-[calc(100vh-200px)] flex items-center justify-center py-16 px-4">
      <div className="text-center max-w-md p-8 rounded-3xl bg-[#0a0e27] border border-white/10 shadow-2xl">
        <div className="w-16 h-16 rounded-2xl bg-[#4361ee]/15 text-[#4361ee] flex items-center justify-center mx-auto mb-6">
          <Compass className="w-8 h-8" />
        </div>

        <div className="text-5xl font-black text-white font-mono mb-2">404</div>
        <h1 className="text-2xl font-bold text-white mb-2">Page Not Found</h1>
        <p className="text-sm text-[#a0a4c1] mb-8 leading-relaxed">
          The path you requested does not exist or has been shifted to a new curriculum roadmap.
        </p>

        <Link
          to="/"
          id="not-found-back-home-btn"
          className="inline-flex items-center justify-center gap-2 px-6 py-3 rounded-full font-semibold text-white bg-gradient-to-r from-[#4361ee] to-[#f72585] shadow-lg shadow-[#4361ee]/20 hover:scale-[1.02] transition-all"
        >
          <Home className="w-4 h-4" />
          <span>Back to Home</span>
        </Link>
      </div>
    </div>
  );
};
