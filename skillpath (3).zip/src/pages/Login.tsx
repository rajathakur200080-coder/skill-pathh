import React, { useState } from 'react';
import { useRouter, Link } from '../router';
import { Mail, Lock, Loader2, CheckCircle2, AlertCircle, ArrowRight } from 'lucide-react';

export const Login: React.FC = () => {
  const { user, loginWithEmail, loginWithGoogle, navigate } = useRouter();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [errors, setErrors] = useState<{ email?: string; password?: string }>({});
  const [isLoading, setIsLoading] = useState(false);
  const [isGoogleLoading, setIsGoogleLoading] = useState(false);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  const validate = () => {
    const newErrors: { email?: string; password?: string } = {};

    if (!email.trim()) {
      newErrors.email = 'Email address is required.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
      newErrors.email = 'Please enter a valid email address.';
    }

    if (!password) {
      newErrors.password = 'Password is required.';
    } else if (password.length < 6) {
      newErrors.password = 'Password must be at least 6 characters.';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    setIsLoading(true);
    setSuccessMessage(null);

    try {
      await loginWithEmail(email.trim());
      setIsLoading(false);
      setSuccessMessage('Successfully logged in! Redirecting to Find My Gap...');
      setTimeout(() => {
        navigate('/find-gap');
      }, 1200);
    } catch {
      setIsLoading(false);
      setErrors({ email: 'Failed to authenticate. Please try again.' });
    }
  };

  const handleGoogleSignIn = async () => {
    setIsGoogleLoading(true);
    setSuccessMessage(null);
    setErrors({});

    try {
      await loginWithGoogle();
      setIsGoogleLoading(false);
      setSuccessMessage('Signed in with Google! Welcome back, Alex.');
      setTimeout(() => {
        navigate('/find-gap');
      }, 1200);
    } catch {
      setIsGoogleLoading(false);
    }
  };

  return (
    <div className="w-full min-h-[calc(100vh-160px)] flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
      <div className="w-full max-w-md">
        
        {/* Form Container */}
        <div className="rounded-3xl bg-[#0a0e27] border border-white/10 p-8 sm:p-10 shadow-2xl relative overflow-hidden">
          {/* Subtle top glow */}
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-48 h-1.5 bg-gradient-to-r from-[#4361ee] to-[#f72585] rounded-full" />

          {/* Header */}
          <div className="text-center mb-8">
            <Link to="/" className="inline-flex items-center gap-2 mb-3">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#4361ee] to-[#f72585] flex items-center justify-center shadow-md shadow-[#4361ee]/20">
                <span className="text-white font-extrabold text-sm">S</span>
              </div>
              <span className="text-xl font-bold tracking-tight text-white">
                Skill<span className="bg-gradient-to-r from-[#4361ee] to-[#f72585] bg-clip-text text-transparent">Path</span>
              </span>
            </Link>
            <h1 className="text-2xl font-bold text-white tracking-tight">
              Welcome Back
            </h1>
            <p className="text-xs sm:text-sm text-[#a0a4c1] mt-1">
              Log in to track your skill gaps and saved resources.
            </p>
          </div>

          {/* Success Banner */}
          {successMessage && (
            <div
              id="login-success-banner"
              className="mb-6 p-4 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-xs sm:text-sm flex items-center gap-3 animate-in fade-in"
            >
              <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
              <span>{successMessage}</span>
            </div>
          )}

          {/* Google Sign In Button */}
          <button
            type="button"
            id="login-google-btn"
            onClick={handleGoogleSignIn}
            disabled={isGoogleLoading || isLoading}
            className="w-full py-3 px-4 rounded-xl bg-white/[0.06] hover:bg-white/[0.1] border border-white/15 text-white text-sm font-medium flex items-center justify-center gap-3 transition-colors cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed focus:outline-none focus:ring-2 focus:ring-[#4361ee]"
          >
            {isGoogleLoading ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin text-[#4361ee]" />
                <span>Connecting to Google...</span>
              </>
            ) : (
              <>
                {/* Standard Google "G" Icon */}
                <svg className="w-4 h-4" viewBox="0 0 24 24">
                  <path
                    fill="#EA4335"
                    d="M12 5c1.6 0 3 .6 4.1 1.6l3.1-3.1C17.3 1.7 14.8 1 12 1 7.4 1 3.5 3.6 1.6 7.4l3.7 2.9C6.2 7.3 8.9 5 12 5z"
                  />
                  <path
                    fill="#4285F4"
                    d="M23.5 12.3c0-.8-.1-1.7-.2-2.3H12v4.6h6.5c-.3 1.5-1.1 2.8-2.4 3.7l3.7 2.9c2.2-2 3.7-5 3.7-8.9z"
                  />
                  <path
                    fill="#FBBC05"
                    d="M5.3 14.7c-.2-.7-.4-1.5-.4-2.7s.1-2 .4-2.7L1.6 6.4C.6 8.3 0 10.1 0 12s.6 3.7 1.6 5.6l3.7-2.9z"
                  />
                  <path
                    fill="#34A853"
                    d="M12 23c3.2 0 6-1.1 8-3l-3.7-2.9c-1.1.7-2.5 1.2-4.3 1.2-3.1 0-5.8-2.3-6.7-5.3L1.6 16C3.5 19.7 7.4 23 12 23z"
                  />
                </svg>
                <span>Continue with Google</span>
              </>
            )}
          </button>

          {/* "or" divider */}
          <div className="relative my-6 text-center">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-white/10" />
            </div>
            <span className="relative px-3 bg-[#0a0e27] text-xs text-[#a0a4c1] uppercase font-mono">
              or
            </span>
          </div>

          {/* Email / Password Form */}
          <form onSubmit={handleSubmit} noValidate className="space-y-4">
            {/* Email Field */}
            <div>
              <label
                htmlFor="login-email"
                className="block text-xs font-semibold uppercase tracking-wider text-[#a0a4c1] mb-1.5"
              >
                Email Address
              </label>
              <div className="relative">
                <Mail className="w-4 h-4 text-[#a0a4c1] absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  id="login-email"
                  type="email"
                  autoComplete="email"
                  value={email}
                  onChange={(e) => {
                    setEmail(e.target.value);
                    if (errors.email) setErrors((prev) => ({ ...prev, email: undefined }));
                  }}
                  placeholder="name@college.edu"
                  className={`w-full bg-[#060815] border rounded-xl pl-10 pr-4 py-2.5 text-sm text-white placeholder-[#a0a4c1]/60 focus:outline-none transition-colors ${
                    errors.email
                      ? 'border-red-500 focus:ring-1 focus:ring-red-500'
                      : 'border-white/15 focus:border-[#4361ee]'
                  }`}
                />
              </div>
              {errors.email && (
                <p id="login-email-error" className="mt-1 text-xs text-red-400 flex items-center gap-1">
                  <AlertCircle className="w-3 h-3" />
                  <span>{errors.email}</span>
                </p>
              )}
            </div>

            {/* Password Field */}
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label
                  htmlFor="login-password"
                  className="block text-xs font-semibold uppercase tracking-wider text-[#a0a4c1]"
                >
                  Password
                </label>
              </div>
              <div className="relative">
                <Lock className="w-4 h-4 text-[#a0a4c1] absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  id="login-password"
                  type="password"
                  autoComplete="current-password"
                  value={password}
                  onChange={(e) => {
                    setPassword(e.target.value);
                    if (errors.password) setErrors((prev) => ({ ...prev, password: undefined }));
                  }}
                  placeholder="••••••••"
                  className={`w-full bg-[#060815] border rounded-xl pl-10 pr-4 py-2.5 text-sm text-white placeholder-[#a0a4c1]/60 focus:outline-none transition-colors ${
                    errors.password
                      ? 'border-red-500 focus:ring-1 focus:ring-red-500'
                      : 'border-white/15 focus:border-[#4361ee]'
                  }`}
                />
              </div>
              {errors.password && (
                <p id="login-password-error" className="mt-1 text-xs text-red-400 flex items-center gap-1">
                  <AlertCircle className="w-3 h-3" />
                  <span>{errors.password}</span>
                </p>
              )}
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              id="login-submit-btn"
              disabled={isLoading || isGoogleLoading}
              className="w-full mt-2 py-3 px-4 rounded-xl bg-gradient-to-r from-[#4361ee] to-[#f72585] hover:opacity-95 text-white text-sm font-semibold shadow-lg shadow-[#4361ee]/20 flex items-center justify-center gap-2 transition-all cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed focus:outline-none focus:ring-2 focus:ring-[#f72585]"
            >
              {isLoading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Logging in...</span>
                </>
              ) : (
                <>
                  <span>Login</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </form>

          {/* Footer link */}
          <div className="mt-8 pt-6 border-t border-white/10 text-center text-xs text-[#a0a4c1]">
            Don't have an account?{' '}
            <Link
              to="/signup"
              id="login-to-signup-link"
              className="text-[#f72585] font-semibold hover:underline"
            >
              Sign Up
            </Link>
          </div>

        </div>

      </div>
    </div>
  );
};
