import React from 'react';
import { Link } from '../router';
import {
  GraduationCap,
  Sparkles,
  Search,
  CheckCircle2,
  ArrowRight,
  ShieldCheck,
  BookOpen,
  Award,
  Zap,
} from 'lucide-react';

export const HowItWorks: React.FC = () => {
  const steps = [
    {
      number: '01',
      title: 'Pick Your Degree',
      subtitle: 'Identify your baseline academic track',
      description:
        'Select your college degree program (BCA, BCom, BBA, BA, or MBA). Whether you are in your freshman year or about to enter campus placements, identifying your academic foundation is the initial milestone.',
      icon: GraduationCap,
      accentColor: 'text-[#4361ee]',
      bgAccent: 'bg-[#4361ee]/15',
      borderAccent: 'border-[#4361ee]/30',
      highlights: [
        'Curated pathways for technical, commercial, creative & management degrees',
        'Updated to reflect recent hiring market shifts and AI industry tooling',
        'Takes less than 10 seconds with zero signup friction',
      ],
    },
    {
      number: '02',
      title: 'We Map the Gaps',
      subtitle: 'Uncover what universities skip',
      description:
        'Our algorithm benchmarks your degree curriculum against active entry-level job descriptions. We isolate the practical tools and frameworks companies test in interviews that university lecture slides omit.',
      icon: Search,
      accentColor: 'text-[#f72585]',
      bgAccent: 'bg-[#f72585]/15',
      borderAccent: 'border-[#f72585]/30',
      highlights: [
        'Concrete list of 4–5 decisive skills with verified market demand',
        'Clear breakdown of why each skill matters to engineering and finance recruiters',
        'Exact comparison of textbook theory vs production standards',
      ],
    },
    {
      number: '03',
      title: 'Learn for Free',
      subtitle: 'Access world-class education at $0 cost',
      description:
        'Forget expensive $2,000 bootcamps. We link you directly to premier, open-access curricula authored by Harvard, University of Helsinki, Microsoft, CFI, and open source communities.',
      icon: CheckCircle2,
      accentColor: 'text-emerald-400',
      bgAccent: 'bg-emerald-500/15',
      borderAccent: 'border-emerald-500/30',
      highlights: [
        '100% free verified resources with no paywalls or sneaky trials',
        'Includes estimated study hours so you can balance college coursework',
        'Direct external links straight to official learning sandboxes',
      ],
    },
  ];

  const faqs = [
    {
      q: 'Do I really not need to pay anything to learn these skills?',
      a: 'Absolutely not. Every single course and resource linked on SkillPath is verified 100% free. We believe education should be accessible regardless of financial background.',
    },
    {
      q: 'Do I need to create an account or sign in to use Find My Gap?',
      a: 'No. The Find My Gap diagnostic tool is completely open to anyone without registering or providing an email address.',
    },
    {
      q: 'How frequently are the skill gaps updated?',
      a: 'We monitor quarterly recruitment reports and startup hiring postings to ensure every listed skill reflects active tech and commerce trends.',
    },
    {
      q: 'What if my degree is not listed?',
      a: 'We currently support BCA, BCom, BBA, BA, and MBA. You can use our Contact page to suggest additional degrees like B.Tech/Engineering or B.Sc!',
    },
  ];

  return (
    <div className="w-full py-12 sm:py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Page Header */}
        <div className="text-center max-w-3xl mx-auto mb-16 sm:mb-20">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white/5 border border-white/10 text-xs font-medium text-[#4361ee] mb-4">
            <Zap className="w-3.5 h-3.5 text-[#4361ee]" />
            <span>Architecture & Methodology</span>
          </div>

          <h1 className="text-3xl sm:text-5xl font-extrabold text-white tracking-tight mb-4">
            How{' '}
            <span className="bg-gradient-to-r from-[#4361ee] to-[#f72585] bg-clip-text text-transparent">
              SkillPath
            </span>{' '}
            Works
          </h1>

          <p className="text-base sm:text-lg text-[#a0a4c1] leading-relaxed">
            A transparent, 3-step engine built to eliminate career uncertainty and equip students with verifiable, resume-ready competencies.
          </p>
        </div>

        {/* 3 Step Visual Breakdown */}
        <div className="space-y-8 sm:space-y-12 mb-24">
          {steps.map((step, idx) => {
            const Icon = step.icon;
            const isReversed = idx % 2 !== 0;

            return (
              <div
                key={step.number}
                id={`how-it-works-step-${step.number}`}
                className="rounded-3xl bg-[#0a0e27] border border-white/10 p-8 sm:p-12 shadow-xl hover:border-white/20 transition-all duration-300"
              >
                <div
                  className={`grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center ${
                    isReversed ? 'lg:flex-row-reverse' : ''
                  }`}
                >
                  {/* Text Column */}
                  <div className="lg:col-span-7">
                    <div className="flex items-center gap-3 mb-4">
                      <span className="text-3xl sm:text-4xl font-black bg-gradient-to-r from-[#4361ee] to-[#f72585] bg-clip-text text-transparent font-mono">
                        {step.number}
                      </span>
                      <span className="h-4 w-[1px] bg-white/20" />
                      <span className="text-xs uppercase tracking-wider font-semibold text-[#a0a4c1]">
                        {step.subtitle}
                      </span>
                    </div>

                    <h2 className="text-2xl sm:text-3xl font-extrabold text-white mb-4">
                      {step.title}
                    </h2>

                    <p className="text-sm sm:text-base text-[#a0a4c1] leading-relaxed mb-6">
                      {step.description}
                    </p>

                    <div className="space-y-2.5">
                      {step.highlights.map((highlight, hIdx) => (
                        <div key={hIdx} className="flex items-start gap-3 text-xs sm:text-sm text-white">
                          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                          <span>{highlight}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Graphic Card Column */}
                  <div className="lg:col-span-5 flex justify-center">
                    <div className="w-full max-w-sm rounded-2xl bg-[#060815] border border-white/10 p-6 sm:p-8 flex flex-col items-center text-center relative overflow-hidden group">
                      <div
                        className={`w-16 h-16 rounded-2xl ${step.bgAccent} ${step.accentColor} flex items-center justify-center mb-6 shadow-lg group-hover:scale-110 transition-transform duration-200`}
                      >
                        <Icon className="w-8 h-8" />
                      </div>

                      <div className="text-lg font-bold text-white mb-2">
                        {step.title}
                      </div>

                      <p className="text-xs text-[#a0a4c1] leading-relaxed">
                        Precision-engineered for maximum career leverage in competitive recruitment pools.
                      </p>

                      <div className="mt-6 pt-4 border-t border-white/5 w-full flex items-center justify-center gap-2 text-xs font-mono text-[#f72585]">
                        <Sparkles className="w-3.5 h-3.5" />
                        <span>Step {step.number} of 03</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* FAQ Section */}
        <div className="max-w-4xl mx-auto mb-20">
          <div className="text-center mb-10">
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white mb-3">
              Frequently Asked Questions
            </h2>
            <p className="text-sm text-[#a0a4c1]">
              Everything you need to know about our data and free learning model.
            </p>
          </div>

          <div className="space-y-4">
            {faqs.map((faq, idx) => (
              <div
                key={idx}
                className="rounded-2xl bg-[#0a0e27] border border-white/10 p-6 text-left"
              >
                <div className="text-base font-semibold text-white mb-2">
                  {faq.q}
                </div>
                <div className="text-sm text-[#a0a4c1] leading-relaxed">
                  {faq.a}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Bottom CTA */}
        <div className="text-center py-10">
          <Link
            to="/find-gap"
            id="how-it-works-bottom-cta"
            className="inline-flex items-center gap-2.5 px-8 py-3.5 rounded-full font-semibold text-white bg-gradient-to-r from-[#4361ee] to-[#f72585] shadow-lg shadow-[#4361ee]/25 hover:scale-[1.02] active:scale-[0.98] transition-all"
          >
            <span>Ready? Check Your Degree Gaps</span>
            <ArrowRight className="w-4 h-4" />
          </Link>
        </div>

      </div>
    </div>
  );
};
