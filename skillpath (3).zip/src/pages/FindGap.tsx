import React, { useState } from 'react';
import { DEGREES_DATA } from '../data/skillsData';
import { DegreeData, Skill } from '../types';
import {
  Search,
  ExternalLink,
  BookOpen,
  Clock,
  Sparkles,
  Info,
  CheckCircle2,
  Code2,
  TrendingUp,
  Briefcase,
  PenTool,
  Award,
  Filter,
} from 'lucide-react';

export const FindGap: React.FC = () => {
  const [selectedDegreeId, setSelectedDegreeId] = useState<string>('bca');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [activeModalSkill, setActiveModalSkill] = useState<Skill | null>(null);

  const selectedDegree: DegreeData =
    DEGREES_DATA.find((d) => d.id === selectedDegreeId) || DEGREES_DATA[0];

  const filteredSkills = selectedDegree.skills.filter((skill) => {
    if (!searchQuery.trim()) return true;
    const query = searchQuery.toLowerCase();
    return (
      skill.name.toLowerCase().includes(query) ||
      skill.category.toLowerCase().includes(query) ||
      skill.whyItMatters.toLowerCase().includes(query)
    );
  });

  const getDegreeIcon = (iconName: string) => {
    switch (iconName) {
      case 'Code2':
        return <Code2 className="w-5 h-5" />;
      case 'TrendingUp':
        return <TrendingUp className="w-5 h-5" />;
      case 'Briefcase':
        return <Briefcase className="w-5 h-5" />;
      case 'PenTool':
        return <PenTool className="w-5 h-5" />;
      case 'Award':
        return <Award className="w-5 h-5" />;
      default:
        return <BookOpen className="w-5 h-5" />;
    }
  };

  return (
    <div className="w-full py-12 sm:py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header Section */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white/5 border border-white/10 text-xs font-medium text-[#f72585] mb-4">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Core Skill Gap Diagnostic</span>
          </div>

          <h1 className="text-3xl sm:text-5xl font-extrabold text-white tracking-tight mb-4">
            Find Your Degree's{' '}
            <span className="bg-gradient-to-r from-[#4361ee] to-[#f72585] bg-clip-text text-transparent">
              Skill Gaps
            </span>
          </h1>

          <p className="text-base sm:text-lg text-[#a0a4c1] leading-relaxed">
            Select your college degree to unveil the exact competencies required by modern employers, and start mastering them immediately for free. No login required.
          </p>
        </div>

        {/* Degree Selector Cards */}
        <div className="mb-10">
          <div className="text-xs font-semibold uppercase tracking-wider text-[#a0a4c1] mb-3 text-center sm:text-left">
            Select Your Degree Track
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3 sm:gap-4">
            {DEGREES_DATA.map((degree) => {
              const isSelected = degree.id === selectedDegreeId;
              return (
                <button
                  key={degree.id}
                  id={`degree-tab-${degree.code.toLowerCase()}`}
                  onClick={() => {
                    setSelectedDegreeId(degree.id);
                    setSearchQuery('');
                  }}
                  className={`group p-4 rounded-2xl border text-left transition-all duration-200 cursor-pointer flex flex-col justify-between ${
                    isSelected
                      ? 'bg-gradient-to-b from-[#141a4a] to-[#0a0e27] border-[#4361ee] shadow-lg shadow-[#4361ee]/20 ring-1 ring-[#4361ee]'
                      : 'bg-[#0a0e27]/80 border-white/10 hover:border-white/20 hover:bg-[#0d1233]'
                  }`}
                  aria-pressed={isSelected}
                >
                  <div className="flex items-center justify-between mb-3">
                    <div
                      className={`p-2.5 rounded-xl transition-colors ${
                        isSelected
                          ? 'bg-[#4361ee] text-white'
                          : 'bg-white/5 text-[#a0a4c1] group-hover:text-white'
                      }`}
                    >
                      {getDegreeIcon(degree.iconName)}
                    </div>
                    <span
                      className={`text-[11px] font-mono px-2 py-0.5 rounded ${
                        isSelected
                          ? 'bg-[#f72585]/20 text-[#f72585] font-bold'
                          : 'text-[#a0a4c1]'
                      }`}
                    >
                      {degree.skills.length} Skills
                    </span>
                  </div>

                  <div>
                    <div className="text-lg font-bold text-white tracking-tight">
                      {degree.code}
                    </div>
                    <div className="text-xs text-[#a0a4c1] line-clamp-1 mt-0.5">
                      {degree.title}
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Selected Degree Overview Banner */}
        <div className="rounded-2xl bg-[#0a0e27] border border-white/10 p-6 sm:p-7 mb-10 shadow-lg">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-white/10">
            <div>
              <div className="flex items-center gap-3">
                <span className="text-2xl font-black text-white tracking-tight">
                  {selectedDegree.code}
                </span>
                <span className="text-sm font-medium text-[#a0a4c1]">
                  — {selectedDegree.title}
                </span>
              </div>
              <p className="text-sm text-white/90 mt-1">
                {selectedDegree.summary}
              </p>
            </div>

            {/* Search Input within degree */}
            <div className="relative min-w-[240px]">
              <Search className="w-4 h-4 text-[#a0a4c1] absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Filter skills..."
                className="w-full bg-[#060815] border border-white/15 rounded-xl pl-9 pr-4 py-2 text-xs text-white placeholder-[#a0a4c1] focus:outline-none focus:border-[#4361ee] transition-colors"
                aria-label="Filter skills by keyword"
              />
            </div>
          </div>

          <div className="mt-4 flex items-start gap-2.5 text-xs text-[#a0a4c1]">
            <Info className="w-4 h-4 text-[#f72585] shrink-0 mt-0.5" />
            <span>
              <strong className="text-white">Industry Reality:</strong> {selectedDegree.industryReality}
            </span>
          </div>
        </div>

        {/* Grid of 4-5 In-Demand Skill Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredSkills.map((skill) => (
            <div
              key={skill.id}
              id={`skill-card-${skill.id}`}
              className="rounded-2xl bg-[#0a0e27] border border-white/10 p-6 flex flex-col justify-between hover:border-[#4361ee]/40 transition-all duration-200 shadow-md group hover:-translate-y-1"
            >
              <div>
                {/* Badge and Category */}
                <div className="flex items-center justify-between gap-2 mb-3">
                  <span className="text-[10px] uppercase font-bold tracking-wider px-2.5 py-1 rounded-full bg-[#4361ee]/15 text-[#4361ee] border border-[#4361ee]/20">
                    {skill.badge}
                  </span>
                  <div className="flex items-center gap-1.5 text-xs text-[#a0a4c1]">
                    <Clock className="w-3.5 h-3.5" />
                    <span>{skill.estimatedHours}</span>
                  </div>
                </div>

                {/* Skill Name */}
                <h3 className="text-lg font-bold text-white mb-2 leading-snug group-hover:text-white">
                  {skill.name}
                </h3>

                {/* Category tag */}
                <div className="text-xs text-[#f72585] font-medium mb-3">
                  {skill.category}
                </div>

                {/* One-line Why It Matters */}
                <p className="text-xs sm:text-sm text-[#a0a4c1] leading-relaxed mb-4">
                  <strong className="text-white/90">Why it matters:</strong> {skill.whyItMatters}
                </p>

                {/* Syllabus Gap Highlight */}
                <div className="p-3 rounded-xl bg-white/[0.03] border border-white/5 mb-5">
                  <div className="text-[11px] font-semibold text-amber-400 mb-1">
                    University Blind Spot:
                  </div>
                  <p className="text-xs text-[#a0a4c1]">
                    {skill.syllabusGap}
                  </p>
                </div>
              </div>

              {/* Action Area: Free Resource Button */}
              <div className="pt-4 border-t border-white/10 flex items-center justify-between gap-3">
                <div className="flex flex-col">
                  <span className="text-[10px] text-[#a0a4c1] uppercase font-mono">Resource</span>
                  <span className="text-xs font-semibold text-white truncate max-w-[170px]" title={skill.freeResourceTitle}>
                    {skill.freeResourceProvider}
                  </span>
                </div>

                <a
                  href={skill.freeResourceUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  id={`btn-resource-${skill.id}`}
                  className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold text-white bg-gradient-to-r from-[#4361ee] to-[#f72585] hover:opacity-90 shadow-sm transition-opacity shrink-0 cursor-pointer focus:outline-none focus:ring-2 focus:ring-[#f72585]"
                >
                  <span>Free Resource</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              </div>
            </div>
          ))}
        </div>

        {filteredSkills.length === 0 && (
          <div className="text-center py-16 bg-[#0a0e27] rounded-2xl border border-white/10 p-8">
            <p className="text-base text-[#a0a4c1] mb-3">
              No skills found matching "{searchQuery}" in {selectedDegree.code}.
            </p>
            <button
              onClick={() => setSearchQuery('')}
              className="text-xs text-white bg-white/10 px-4 py-2 rounded-lg hover:bg-white/20 transition-colors"
            >
              Clear Filter
            </button>
          </div>
        )}

      </div>
    </div>
  );
};
